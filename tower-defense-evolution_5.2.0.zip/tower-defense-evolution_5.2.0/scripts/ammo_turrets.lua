-- Helper function to check if a table contains a value
function table.contains(t, value)
    if not t or type(t) ~= "table" then return false end
    for _, v in pairs(t) do
        if v == value then return true end
    end
    return false
end

-- NEW: Ammo preference system - higher tier ammo is preferred
local AMMO_PREFERENCES = {
    ["firearm-magazine"] = 1,           -- Yellow ammo - lowest priority
    ["piercing-rounds-magazine"] = 2,   -- Red ammo - medium priority  
    ["uranium-rounds-magazine"] = 3     -- Uranium ammo - highest priority
}

-- NEW: Get ammo preference (higher number = better ammo)
function get_ammo_preference(ammo_name)
    return AMMO_PREFERENCES[ammo_name] or 0
end

-- NEW: Magazine storage system with limits
function initialize_magazine_storage()
    if not storage.tde.magazines then
        storage.tde.magazines = {}
    end
    
    -- Set storage limits for each ammo type (prevent infinite storage)
    local storage_limits = {
        ["firearm-magazine"] = 10000,           -- 10k yellow ammo max
        ["piercing-rounds-magazine"] = 5000,    -- 5k red ammo max  
        ["uranium-rounds-magazine"] = 2000      -- 2k uranium ammo max
    }
    
    -- Initialize magazine storage with limits
    for ammo_name, limit in pairs(storage_limits) do
        if not storage.tde.magazines[ammo_name] then
            storage.tde.magazines[ammo_name] = {
                count = 0,
                limit = limit
            }
        end
    end
end

-- NEW: Add ammo to storage with limit checking
function add_ammo_to_storage(ammo_name, count)
    if not storage.tde.magazines or not storage.tde.magazines[ammo_name] then
        return 0 -- Can't store unknown ammo type
    end
    
    local magazine_data = storage.tde.magazines[ammo_name]
    local space_available = magazine_data.limit - magazine_data.count
    
    if space_available <= 0 then
        return 0 -- Storage full
    end
    
    local to_store = math.min(count, space_available)
    magazine_data.count = magazine_data.count + to_store
    
    return to_store
end

-- NEW: Get ammo from storage
function get_ammo_from_storage(ammo_name, count)
    if not storage.tde.magazines or not storage.tde.magazines[ammo_name] then
        return 0
    end
    
    local magazine_data = storage.tde.magazines[ammo_name]
    local available = magazine_data.count
    
    if available <= 0 then
        return 0
    end
    
    local to_get = math.min(count, available)
    magazine_data.count = magazine_data.count - to_get
    
    return to_get
end

-- NEW: Get total ammo count in storage
function get_total_ammo_in_storage()
    local total = 0
    if storage.tde.magazines then
        for ammo_name, data in pairs(storage.tde.magazines) do
            total = total + data.count
        end
    end
    return total
end

function register_master_ammo_chest(chest)
    if not chest or not chest.valid or not chest.unit_number then
      log("Cannot register master ammo chest - invalid entity")
      return
    end
    
    storage.tde.master_ammo_chests[chest.unit_number] = {
      entity = chest,
      position = chest.position
      -- Note: No player tracking - all chests contribute to the same objective
      -- regardless of who placed them (multiplayer-friendly)
    }
    
    game.print("Master Ammo Chest registered for global distribution!", {r = 0, g = 1, b = 0})
    log("Registered Master Ammo Chest at " .. chest.position.x .. "," .. chest.position.y)
end
  
function unregister_master_ammo_chest(chest)
    if chest and chest.unit_number then
      storage.tde.master_ammo_chests[chest.unit_number] = nil
      log("Unregistered Master Ammo Chest")
    end
end
  
function register_turret(turret)
    if not turret or not turret.valid or not turret.unit_number then
      log("Cannot register turret - invalid entity")
      return
    end
    
    local ammo_types = get_turret_ammo_type(turret)
    if ammo_types then
      storage.tde.global_turrets[turret.unit_number] = {
        entity = turret,
        ammo_types = ammo_types, -- Store as array of compatible ammo types
        position = turret.position
        -- Note: No player tracking - all turrets contribute to the same objective
        -- regardless of who placed them (multiplayer-friendly)
      }
      
      -- Log all compatible ammo types
      local ammo_list = ""
      if type(ammo_types) == "table" then
        ammo_list = table.concat(ammo_types, ", ")
      else
        ammo_list = tostring(ammo_types)
      end
      
      log("Registered turret " .. turret.name .. " at " .. turret.position.x .. "," .. turret.position.y .. " (needs " .. ammo_list .. ")")
      game.print("Turret registered: " .. turret.name .. " (needs " .. ammo_list .. ")", {r = 0, g = 1, b = 0.5})
    else
      log("Turret " .. turret.name .. " doesn't need ammo - not registered")
    end
end
  
function unregister_turret(turret)
    if turret and turret.unit_number then
      storage.tde.global_turrets[turret.unit_number] = nil
      log("Unregistered turret")
    end
end
  
function is_turret(entity)
    return entity.type == "ammo-turret" or entity.type == "electric-turret" or entity.type == "fluid-turret"
end
  
function get_turret_ammo_type(turret)
    if turret.name == "gun-turret" then
      -- Gun turrets can accept multiple ammo types - return a list of compatible types
      return {
        "firearm-magazine",
        "piercing-rounds-magazine", 
        "uranium-rounds-magazine"
      }
    elseif turret.name == "laser-turret" then
      return nil -- Laser turrets don't need ammo
    elseif turret.name == "flamethrower-turret" then
      return nil -- Flamethrower turrets use fluid, not ammo
    end
    return nil
end
  
-- CORREGIDO: Sistema de distribución de munición SIMPLIFICADO - Volver a lógica que funcionaba
function process_ammo_distribution()
    if game.tick % 180 ~= 0 then return end -- Every 3 seconds
    
    -- CRITICAL FIX: Add error handling to prevent crashes
    local success, error_msg = pcall(function()
        if not storage.tde or not storage.tde.master_ammo_chests or not storage.tde.global_turrets then
          return
        end
        
        -- NEW: Initialize magazine storage if needed
        initialize_magazine_storage()
        
        -- Limpiar torretas inválidas primero
        local valid_turret_count = 0
        for turret_id, turret_data in pairs(storage.tde.global_turrets) do
          if turret_data.entity and turret_data.entity.valid and turret_data.ammo_types then
            valid_turret_count = valid_turret_count + 1
          else
            storage.tde.global_turrets[turret_id] = nil
          end
        end
        
        -- Si no hay torretas válidas, no hacer nada (no tocar cofres)
        if valid_turret_count == 0 then
          -- Debug cada minuto
          if game.tick % 3600 == 0 then
            log("MAC System: No valid turrets found, skipping ammo collection")
          end
          return
        end
        
        local chest_count = 0
        
        -- NEW: Collect ammo from Master Ammo Chests into storage system
        for chest_id, chest_data in pairs(storage.tde.master_ammo_chests) do
          if chest_data.entity and chest_data.entity.valid then
            chest_count = chest_count + 1
            local inventory = chest_data.entity.get_inventory(defines.inventory.chest)
            
            if inventory then
              for i = 1, #inventory do
                local stack = inventory[i]
                -- CRITICAL FIX: Add proper validation before accessing stack properties
                if stack and stack.valid_for_read and stack.name and stack.count and is_ammunition(stack.name) then
                  -- NEW: Add to storage with limit checking
                  local stored = add_ammo_to_storage(stack.name, stack.count)
                  if stored > 0 then
                    stack.count = stack.count - stored
                    if stack.count == 0 then
                      stack.clear()
                    end
                    
                    -- Debug: Log storage limits
                    if game.tick % 3600 == 0 then
                      local magazine_data = storage.tde.magazines[stack.name]
                      if magazine_data and magazine_data.count >= magazine_data.limit * 0.9 then
                        game.print(string.format("Warning: %s storage is %d%% full (%d/%d)", 
                          stack.name, math.floor(magazine_data.count / magazine_data.limit * 100), 
                          magazine_data.count, magazine_data.limit), {r = 1, g = 0.8, b = 0})
                      end
                    end
                  end
                end
              end
            end
          else
            storage.tde.master_ammo_chests[chest_id] = nil
            log("Removed invalid Master Ammo Chest " .. chest_id)
          end
        end
        
        -- NEW: Distribute ammo from storage to turrets with preference sorting
        distribute_ammo_from_storage_to_turrets()
        
        -- Debug output every minute
        if game.tick % 3600 == 0 and (chest_count > 0 or valid_turret_count > 0) then
          log(string.format("MAC System: %d chests, %d turrets registered", chest_count, valid_turret_count))
          log(string.format("MAC Storage: %d total ammo in storage", get_total_ammo_in_storage()))
          
          -- Log storage status
          if storage.tde.magazines then
            for ammo_name, data in pairs(storage.tde.magazines) do
              if data.count > 0 then
                log(string.format("  %s: %d/%d (%.1f%%)", ammo_name, data.count, data.limit, 
                  data.count / data.limit * 100))
              end
            end
          end
        end
    end)
    
    -- CRITICAL FIX: Handle any errors gracefully
    if not success then
        log("TDE: Error in process_ammo_distribution: " .. tostring(error_msg))
        -- Don't crash the game, just log the error and continue
    end
end
  
-- CORREGIDO: Función is_ammunition mejorada
function is_ammunition(item_name)
    if not item_name then return false end
    
    -- Hardcoded ammunition types para evitar problemas con prototypes
    local ammo_types = {
      ["firearm-magazine"] = true,
      ["piercing-rounds-magazine"] = true,
      ["uranium-rounds-magazine"] = true,
      ["shotgun-shell"] = true,
      ["piercing-shotgun-shell"] = true,
      ["cannon-shell"] = true,
      ["explosive-cannon-shell"] = true,
      ["uranium-cannon-shell"] = true,
      ["explosive-uranium-cannon-shell"] = true,
      ["artillery-shell"] = true,
      ["rocket"] = true,
      ["explosive-rocket"] = true,
      ["atomic-bomb"] = true,
      ["flamethrower-ammo"] = true
    }
    
    return ammo_types[item_name] or false
end
  
function distribute_ammo_to_turrets_simple(total_ammo)
    if not total_ammo or not next(total_ammo) then
        return
    end

    -- First collect all valid turrets that need ammo
    local turrets_needing_ammo = {}
    for turret_id, turret_data in pairs(storage.tde.global_turrets) do
        if turret_data.entity and turret_data.entity.valid and turret_data.ammo_types then
            table.insert(turrets_needing_ammo, turret_data)
        end
    end

    if #turrets_needing_ammo == 0 then
        return
    end

    -- Distribute each ammo type
    for ammo_name, total_count in pairs(total_ammo) do
        local distributed_count = 0
        local turrets_to_feed = {}

        -- Find turrets that can use this ammo type
        for _, turret_data in pairs(turrets_needing_ammo) do
            if turret_data.ammo_types and table.contains(turret_data.ammo_types, ammo_name) then
                table.insert(turrets_to_feed, turret_data)
            end
        end

        if #turrets_to_feed > 0 then
            -- Calculate how much ammo each turret should get (minimum 1)
            local ammo_per_turret = math.max(1, math.floor(total_count / #turrets_to_feed))
            
            -- First pass: distribute ammo_per_turret to each turret
            for _, turret_data in pairs(turrets_to_feed) do
                if distributed_count < total_count then
                    local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
                    if inventory then
                        local to_insert = math.min(ammo_per_turret, total_count - distributed_count)
                        if to_insert > 0 then
                            local inserted = inventory.insert({name = ammo_name, count = to_insert})
                            distributed_count = distributed_count + inserted
                        end
                    end
                end
            end

            -- Second pass: distribute any remaining ammo
            local remaining_ammo = total_count - distributed_count
            if remaining_ammo > 0 then
                for _, turret_data in pairs(turrets_to_feed) do
                    if remaining_ammo <= 0 then break end
                    local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
                    if inventory then
                        local inserted = inventory.insert({name = ammo_name, count = 1})
                        remaining_ammo = remaining_ammo - inserted
                        distributed_count = distributed_count + inserted
                    end
                end
            end

            -- Return any unused ammo to chests instead of losing it
            local unused_ammo = total_count - distributed_count
            if unused_ammo > 0 then
                for chest_id, chest_data in pairs(storage.tde.master_ammo_chests) do
                    if chest_data.entity and chest_data.entity.valid then
                        local inventory = chest_data.entity.get_inventory(defines.inventory.chest)
                        if inventory then
                            local inserted = inventory.insert({name = ammo_name, count = unused_ammo})
                            if inserted > 0 then
                                unused_ammo = unused_ammo - inserted
                                if unused_ammo <= 0 then break end
                            end
                        end
                    end
                end
            end

            -- Log the distribution result
            if distributed_count > 0 then
                game.print(string.format("Distributed %d %s to %d turrets", 
                    distributed_count, ammo_name, #turrets_to_feed), {r = 0, g = 0.8, b = 1})
            end
        else
            log("No compatible turrets found for " .. ammo_name .. " - this shouldn't happen")
        end
    end
end

-- ARREGLADO: Sistema de balanceo de munición entre torretas - SIMPLIFICADO Y FUNCIONAL
function balance_ammo_between_turrets()
    if not storage.tde or not storage.tde.global_turrets then
      return
    end
    
    -- CRITICAL FIX: Add error handling to prevent crashes
    local success, error_msg = pcall(function()
        log("TDE: Starting ammo balancing...")
        
        -- Agrupar torretas por tipo de munición
        local turret_groups = {}
        local total_turrets = 0
        
        for turret_id, turret_data in pairs(storage.tde.global_turrets) do
          if turret_data.entity and turret_data.entity.valid and turret_data.ammo_types then
            -- Group turrets by their compatible ammo types
            for _, ammo_type in pairs(turret_data.ammo_types) do
              turret_groups[ammo_type] = turret_groups[ammo_type] or {}
              -- Check if this turret is already in this group to avoid duplicates
              local already_in_group = false
              for _, existing_turret in pairs(turret_groups[ammo_type]) do
                if existing_turret.entity.unit_number == turret_data.entity.unit_number then
                  already_in_group = true
                  break
                end
              end
              if not already_in_group then
                table.insert(turret_groups[ammo_type], turret_data)
              end
            end
            total_turrets = total_turrets + 1
          else
            storage.tde.global_turrets[turret_id] = nil
          end
        end
        
        if total_turrets == 0 then
          return
        end
        
        log("TDE: Found " .. total_turrets .. " turrets to balance")
        
        -- Balancear cada grupo de torretas
        local total_redistributed = 0
        for ammo_type, turrets in pairs(turret_groups) do
          if #turrets > 1 then -- Solo balancear si hay más de 1 torreta
            local redistributed = balance_ammo_group_simple(turrets, ammo_type)
            total_redistributed = total_redistributed + redistributed
          end
        end
        
        if total_redistributed > 0 then
          game.print(string.format("Rebalanced %d ammo among turrets", total_redistributed), {r = 0, g = 0.8, b = 1})
          log("TDE: Ammo balancing completed - redistributed " .. total_redistributed .. " ammo")
        end
    end)
    
    -- CRITICAL FIX: Handle any errors gracefully
    if not success then
        log("TDE: Error in balance_ammo_between_turrets: " .. tostring(error_msg))
        -- Don't crash the game, just log the error and continue
    end
end
  
-- NUEVA: Función de balanceo SIMPLE que SÍ funciona
function balance_ammo_group_simple(turrets, ammo_type)
    local turret_inventories = {}
    local total_ammo = 0
    
    -- Paso 1: Recopilar información de todas las torretas
    for _, turret_data in pairs(turrets) do
      if turret_data.entity and turret_data.entity.valid and turret_data.ammo_types then
        local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
        if inventory then
          local ammo_count = 0
          
          -- Contar munición total en esta torreta (solo del tipo que estamos balanceando)
          for i = 1, #inventory do
            local stack = inventory[i]
            -- CRITICAL FIX: Add proper validation before accessing stack properties
            if stack and stack.valid_for_read and stack.name and stack.count and stack.name == ammo_type then
              ammo_count = ammo_count + stack.count
            end
          end
          
          table.insert(turret_inventories, {
            turret_data = turret_data,
            inventory = inventory,
            current_ammo = ammo_count
          })
          total_ammo = total_ammo + ammo_count
        end
      end
    end
    
    if #turret_inventories < 2 or total_ammo == 0 then
      return 0 -- No hay suficientes torretas o munición para balancear
    end
    
    -- Paso 2: Calcular si hay desequilibrio significativo
    local max_ammo = 0
    local min_ammo = math.huge
    
    for _, turret_inv in pairs(turret_inventories) do
      max_ammo = math.max(max_ammo, turret_inv.current_ammo)
      min_ammo = math.min(min_ammo, turret_inv.current_ammo)
    end
    
    local difference = max_ammo - min_ammo
    log("TDE: Ammo difference: " .. difference .. " (max: " .. max_ammo .. ", min: " .. min_ammo .. ")")
    
    -- Solo balancear si hay una diferencia significativa (más de 15 municiones)
    if difference < 15 then
      log("TDE: Difference too small, skipping balance")
      return 0
    end
    
    -- Paso 3: Redistribución simple - mover munición de torretas con más a torretas con menos
    local redistributed = 0
    local target_ammo = math.floor(total_ammo / #turret_inventories)
    
    -- Recoger exceso de torretas que tienen más que el promedio + 5
    local excess_ammo_items = {}
    
    for _, turret_inv in pairs(turret_inventories) do
      if turret_inv.current_ammo > target_ammo + 5 then
        local excess = turret_inv.current_ammo - target_ammo
        local removed = 0
        
        -- Remover munición excedente (solo del tipo específico)
        for i = 1, #turret_inv.inventory do
          local stack = turret_inv.inventory[i]
          -- CRITICAL FIX: Add proper validation before accessing stack properties
          if stack and stack.valid_for_read and stack.name and stack.count and stack.name == ammo_type and removed < excess then
            local to_remove = math.min(excess - removed, stack.count)
            
            -- Guardar munición removida
            table.insert(excess_ammo_items, {
              name = stack.name,
              count = to_remove
            })
            
            stack.count = stack.count - to_remove
            removed = removed + to_remove
            redistributed = redistributed + to_remove
            
            if stack.count == 0 then
              stack.clear()
            end
          end
        end
      end
    end
    
    -- Distribuir munición excedente a torretas que tienen menos que el promedio - 5
    for _, turret_inv in pairs(turret_inventories) do
      if turret_inv.current_ammo < target_ammo - 5 and #excess_ammo_items > 0 then
        local needed = target_ammo - turret_inv.current_ammo
        
        -- Dar munición de la reserva de exceso
        for i = #excess_ammo_items, 1, -1 do
          local ammo_item = excess_ammo_items[i]
          if needed > 0 and ammo_item.count > 0 then
            local to_give = math.min(needed, ammo_item.count)
            local inserted = turret_inv.inventory.insert({name = ammo_item.name, count = to_give})
            
            ammo_item.count = ammo_item.count - inserted
            needed = needed - inserted
            
            if ammo_item.count == 0 then
              table.remove(excess_ammo_items, i)
            end
          end
        end
      end
    end
    
    log("TDE: Redistributed " .. redistributed .. " " .. ammo_type .. " ammo")
    return redistributed
end
  
function find_compatible_turrets(ammo_name, turret_groups)
    local ammo_compatibility = {
      ["firearm-magazine"] = "firearm-magazine",
      ["piercing-rounds-magazine"] = "firearm-magazine",
      ["uranium-rounds-magazine"] = "firearm-magazine"
    }
    
    local compatible_type = ammo_compatibility[ammo_name]
    return (compatible_type and turret_groups[compatible_type]) or {}
end

-- NEW: Distribute ammo from storage to turrets with preference sorting
function distribute_ammo_from_storage_to_turrets()
    if not storage.tde.magazines then
        return
    end

    -- First collect all valid turrets that need ammo
    local turrets_needing_ammo = {}
    for turret_id, turret_data in pairs(storage.tde.global_turrets) do
        if turret_data.entity and turret_data.entity.valid and turret_data.ammo_types then
            table.insert(turrets_needing_ammo, turret_data)
        end
    end

    if #turrets_needing_ammo == 0 then
        return
    end

    -- NEW: Sort ammo types by preference (highest priority first)
    local ammo_types_available = {}
    for ammo_name, data in pairs(storage.tde.magazines) do
        if data.count > 0 then
            table.insert(ammo_types_available, {
                name = ammo_name,
                count = data.count,
                preference = get_ammo_preference(ammo_name)
            })
        end
    end
    
    -- Sort by preference (highest first)
    table.sort(ammo_types_available, function(a, b)
        return a.preference > b.preference
    end)

    -- Distribute each ammo type in preference order
    for _, ammo_data in pairs(ammo_types_available) do
        local ammo_name = ammo_data.name
        local total_count = ammo_data.count
        local distributed_count = 0
        local turrets_to_feed = {}

        -- Find turrets that can use this ammo type
        for _, turret_data in pairs(turrets_needing_ammo) do
            if turret_data.ammo_types and table.contains(turret_data.ammo_types, ammo_name) then
                table.insert(turrets_to_feed, turret_data)
            end
        end

        if #turrets_to_feed > 0 then
            -- Calculate how much ammo each turret should get (minimum 1)
            local ammo_per_turret = math.max(1, math.floor(total_count / #turrets_to_feed))
            
            -- First pass: distribute ammo_per_turret to each turret
            for _, turret_data in pairs(turrets_to_feed) do
                if distributed_count < total_count then
                    local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
                    if inventory then
                        local to_insert = math.min(ammo_per_turret, total_count - distributed_count)
                        if to_insert > 0 then
                            -- NEW: Get ammo from storage instead of using total_ammo
                            local ammo_to_give = get_ammo_from_storage(ammo_name, to_insert)
                            if ammo_to_give > 0 then
                                local inserted = inventory.insert({name = ammo_name, count = ammo_to_give})
                                distributed_count = distributed_count + inserted
                                
                                -- If we couldn't insert all the ammo we got from storage, return the excess
                                if inserted < ammo_to_give then
                                    add_ammo_to_storage(ammo_name, ammo_to_give - inserted)
                                end
                            end
                        end
                    end
                end
            end

            -- Second pass: distribute any remaining ammo
            local remaining_ammo = total_count - distributed_count
            if remaining_ammo > 0 then
                for _, turret_data in pairs(turrets_to_feed) do
                    if remaining_ammo <= 0 then break end
                    local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
                    if inventory then
                        local ammo_to_give = get_ammo_from_storage(ammo_name, 1)
                        if ammo_to_give > 0 then
                            local inserted = inventory.insert({name = ammo_name, count = ammo_to_give})
                            remaining_ammo = remaining_ammo - inserted
                            distributed_count = distributed_count + inserted
                            
                            -- Return excess if couldn't insert
                            if inserted < ammo_to_give then
                                add_ammo_to_storage(ammo_name, ammo_to_give - inserted)
                            end
                        end
                    end
                end
            end

            -- Log the distribution result
            if distributed_count > 0 then
                local preference_text = ""
                if ammo_data.preference == 3 then
                    preference_text = " (HIGH PRIORITY)"
                elseif ammo_data.preference == 2 then
                    preference_text = " (MEDIUM PRIORITY)"
                end
                
                game.print(string.format("Distributed %d %s to %d turrets%s", 
                    distributed_count, ammo_name, #turrets_to_feed, preference_text), {r = 0, g = 0.8, b = 1})
            end
        else
            log("No compatible turrets found for " .. ammo_name .. " - this shouldn't happen")
        end
    end
end

