-- Tower Defense Evolution - Pure Kills System
-- Complete tower defense conversion with kill-based tech progression
-- VERSION 4.0.0 v11 - WAVE COUNT DEFINITIVAMENTE ARREGLADO + MAC AUTO-RECONSTRUCTION + AMMO REDISTRIBUTION FIXED

-- ===== GLOBAL VARIABLES =====
local SAFE_ZONE_RADIUS = 175  -- 150-200 tiles safe zone
local NEST_SPACING = 5        -- 1 nest every 5 tiles
local WAVE_INTERVAL = 36000   -- 10 minutes in ticks (10 * 60 * 60 = 36000)
local BOSS_EVERY = 10         -- Boss every 10 waves
local MAX_DISTANCE_HP = 50000 -- Max distance for HP scaling

-- COMPLETE TECHNOLOGY COSTS DATABASE - ESCALADOS Y MÁS CAROS
local TECH_KILL_COSTS = {
  -- Starting techs (accesibles al inicio)
  ["automation"] = 10,
  ["logistics"] = 25,
  ["military"] = 30,
  ["electronics"] = 40,
  
  -- Basic production (baratos pero no triviales)
  ["steel-processing"] = 80,
  ["fast-inserter"] = 120,
  ["long-handed-inserter"] = 100,
  ["filter-inserter"] = 180,
  ["stack-inserter"] = 300,
  ["bulk-inserter"] = 450,
  
  -- Military techs (moderados pero importantes)
  ["gun-turret"] = 35,  -- Mantener barato para inicio
  ["stone-walls"] = 50,
  ["gates"] = 80,
  ["military-2"] = 150,
  ["military-3"] = 400,
  ["military-4"] = 800,
  ["laser-turrets"] = 500,  -- Mucho más caro
  ["flamethrower"] = 350,
  ["land-mine"] = 120,
  ["defender"] = 250,
  ["distractor"] = 500,
  ["destroyer"] = 800,
  ["discharge-defense-equipment"] = 600,
  ["energy-shield-equipment"] = 400,
  ["energy-shield-mk2-equipment"] = 1000,
  ["battery-equipment"] = 200,
  ["battery-mk2-equipment"] = 500,
  ["personal-laser-defense-equipment"] = 800,
  ["exoskeleton-equipment"] = 1200,
  ["personal-roboport-equipment"] = 600,
  ["personal-roboport-mk2-equipment"] = 1500,
  
  -- Advanced production (caros)
  ["advanced-electronics"] = 200,
  ["advanced-electronics-2"] = 500,
  ["engine"] = 250,
  ["oil-processing"] = 300,
  ["plastics"] = 250,
  ["chemistry"] = 400,
  ["advanced-oil-processing"] = 600,
  ["coal-liquefaction"] = 800,
  ["sulfur-processing"] = 300,
  ["explosives"] = 250,
  ["battery"] = 300,
  ["flying-robot-frame"] = 400,
  ["low-density-structure"] = 600,
  ["rocket-fuel"] = 500,
  ["nuclear-fuel-reprocessing"] = 1200,
  ["kovarex-enrichment-process"] = 1500,
  ["uranium-processing"] = 800,
  
  -- Logistics (escalados)
  ["logistics-2"] = 300,
  ["logistics-3"] = 600,
  ["construction-robotics"] = 500,
  ["logistic-robotics"] = 450,
  ["robotics"] = 400,
  ["worker-robots-speed-1"] = 300,
  ["worker-robots-speed-2"] = 500,
  ["worker-robots-speed-3"] = 800,
  ["worker-robots-speed-4"] = 1200,
  ["worker-robots-speed-5"] = 1800,
  ["worker-robots-storage-1"] = 300,
  ["worker-robots-storage-2"] = 500,
  ["worker-robots-storage-3"] = 800,
  ["logistic-system"] = 600,
  ["auto-character-logistic-trash-slots"] = 400,
  ["character-logistic-slots-1"] = 250,
  ["character-logistic-slots-2"] = 400,
  ["character-logistic-slots-3"] = 600,
  ["character-logistic-slots-4"] = 800,
  ["character-logistic-slots-5"] = 1000,
  ["character-logistic-slots-6"] = 1200,
  
  -- High-tier production (muy caros)
  ["electric-furnace"] = 400,
  ["productivity-module"] = 600,
  ["speed-module"] = 500,
  ["efficiency-module"] = 450,
  ["productivity-module-2"] = 1200,
  ["speed-module-2"] = 1000,
  ["efficiency-module-2"] = 900,
  ["productivity-module-3"] = 2400,
  ["speed-module-3"] = 2000,
  ["efficiency-module-3"] = 1800,
  ["effect-transmission"] = 300,
  ["beacon"] = 800,
  
  -- Power (moderados)
  ["solar-energy"] = 250,
  ["electric-energy-accumulators"] = 300,
  ["electric-energy-distribution-1"] = 150,
  ["electric-energy-distribution-2"] = 300,
  ["nuclear-power"] = 1500,
  ["nuclear-fuel"] = 1000,
  ["steam-power"] = 200,
  
  -- Transportation (escalados)
  ["railway"] = 400,
  ["automated-rail-transportation"] = 600,
  ["rail-signals"] = 300,
  ["rail-chain-signal"] = 400,
  ["braking-force-1"] = 250,
  ["braking-force-2"] = 350,
  ["braking-force-3"] = 500,
  ["braking-force-4"] = 700,
  ["braking-force-5"] = 900,
  ["braking-force-6"] = 1100,
  ["braking-force-7"] = 1300,
  ["fluid-wagon"] = 500,
  ["cargo-landing-pad"] = 1500,
  
  -- Research and labs (caros)
  ["research-speed-1"] = 300,
  ["research-speed-2"] = 600,
  ["research-speed-3"] = 1200,
  ["research-speed-4"] = 1800,
  ["research-speed-5"] = 2400,
  ["research-speed-6"] = 3000,
  ["lab-productivity-1"] = 400,
  ["lab-productivity-2"] = 800,
  ["lab-productivity-3"] = 1200,
  
  -- Mining and processing (escalados)
  ["mining-productivity-1"] = 300,
  ["mining-productivity-2"] = 500,
  ["mining-productivity-3"] = 800,
  ["mining-productivity-4"] = 1200,
  ["stronger-explosives-1"] = 250,
  ["stronger-explosives-2"] = 400,
  ["stronger-explosives-3"] = 600,
  ["stronger-explosives-4"] = 800,
  ["stronger-explosives-5"] = 1000,
  ["stronger-explosives-6"] = 1200,
  ["stronger-explosives-7"] = 1400,
  
  -- Space and endgame (extremadamente caros)
  ["rocket-silo"] = 3000,
  ["space-science-pack"] = 2500,
  ["satellite"] = 2000,
  ["space-platform"] = 4000,
  ["space-platform-foundation"] = 3000,
  ["cargo-bay"] = 2500,
  ["asteroid-reprocessing"] = 3500,
  ["space-platform-thruster"] = 2800,
  ["planet-discovery-vulcanus"] = 5000,
  ["planet-discovery-gleba"] = 5000,
  ["planet-discovery-fulgora"] = 5000,
  ["planet-discovery-aquilo"] = 6000,
  
  -- Quality modules (muy caros)
  ["quality-module"] = 800,
  ["quality-module-2"] = 1800,
  ["quality-module-3"] = 3600,
  
  -- Fluid handling (moderados)
  ["fluid-handling"] = 200,
  ["storage-tank"] = 150,
  ["pump"] = 250,
  ["barrel-filling"] = 300,
  
  -- Weapons and armor (escalados progresivamente)
  ["physical-projectile-damage-1"] = 200,
  ["physical-projectile-damage-2"] = 350,
  ["physical-projectile-damage-3"] = 500,
  ["physical-projectile-damage-4"] = 700,
  ["physical-projectile-damage-5"] = 900,
  ["physical-projectile-damage-6"] = 1200,
  ["physical-projectile-damage-7"] = 1500,
  ["weapon-shooting-speed-1"] = 200,
  ["weapon-shooting-speed-2"] = 350,
  ["weapon-shooting-speed-3"] = 500,
  ["weapon-shooting-speed-4"] = 700,
  ["weapon-shooting-speed-5"] = 900,
  ["weapon-shooting-speed-6"] = 1200,
  ["laser-weapons-damage-1"] = 300,
  ["laser-weapons-damage-2"] = 500,
  ["laser-weapons-damage-3"] = 800,
  ["laser-weapons-damage-4"] = 1100,
  ["laser-weapons-damage-5"] = 1400,
  ["laser-weapons-damage-6"] = 1700,
  ["laser-weapons-damage-7"] = 2000,
  ["energy-weapons-damage-1"] = 300,
  ["energy-weapons-damage-2"] = 500,
  ["energy-weapons-damage-3"] = 800,
  ["energy-weapons-damage-4"] = 1100,
  ["energy-weapons-damage-5"] = 1400,
  ["energy-weapons-damage-6"] = 1700,
  ["energy-weapons-damage-7"] = 2000,
  ["refined-flammables-1"] = 250,
  ["refined-flammables-2"] = 400,
  ["refined-flammables-3"] = 600,
  ["refined-flammables-4"] = 800,
  ["refined-flammables-5"] = 1000,
  ["refined-flammables-6"] = 1200,
  ["refined-flammables-7"] = 1400,
  ["modular-armor"] = 500,
  ["power-armor"] = 1200,
  ["power-armor-mk2"] = 2500,
  ["heavy-armor"] = 200,
  
  -- Follower robots (escalados)
  ["follower-robot-count-1"] = 250,
  ["follower-robot-count-2"] = 400,
  ["follower-robot-count-3"] = 600,
  ["follower-robot-count-4"] = 800,
  ["follower-robot-count-5"] = 1000,
  ["follower-robot-count-6"] = 1200,
  ["follower-robot-count-7"] = 1400,
  
  -- Artillery (muy caros)
  ["artillery"] = 2000,
  ["artillery-shell-range-1"] = 600,
  ["artillery-shell-speed-1"] = 600,
  
  -- Turret damage upgrades (escalados)
  ["physical-projectile-damage-for-turrets-1"] = 300,
  ["physical-projectile-damage-for-turrets-2"] = 500,
  ["physical-projectile-damage-for-turrets-3"] = 800,
  ["laser-turret-damage-1"] = 400,
  ["laser-turret-damage-2"] = 600,
  ["laser-turret-damage-3"] = 900,
  ["laser-turret-damage-4"] = 1200,
  ["laser-turret-damage-5"] = 1500,
  ["laser-turret-damage-6"] = 1800,
  ["laser-turret-damage-7"] = 2100,
  
  -- Stack size bonuses (escalados)
  ["stack-inserter-capacity-bonus-1"] = 200,
  ["stack-inserter-capacity-bonus-2"] = 350,
  ["stack-inserter-capacity-bonus-3"] = 500,
  ["stack-inserter-capacity-bonus-4"] = 700,
  ["stack-inserter-capacity-bonus-5"] = 900,
  ["stack-inserter-capacity-bonus-6"] = 1100,
  ["stack-inserter-capacity-bonus-7"] = 1300,
  
  -- Toolbelt (escalados)
  ["toolbelt"] = 150,
  ["character-inventory-slots-1"] = 200,
  ["character-inventory-slots-2"] = 350,
  ["character-inventory-slots-3"] = 500,
  ["character-inventory-slots-4"] = 700,
  ["character-inventory-slots-5"] = 900,
  ["character-inventory-slots-6"] = 1100,
  
  -- Circuit network (moderados)
  ["circuit-network"] = 250,
  ["advanced-circuit-network"] = 500,
  
  -- Concrete (moderados)
  ["concrete"] = 300,
  ["refined-concrete"] = 500,
  ["landfill"] = 250,
  
  -- Cliff explosives (moderado)
  ["cliff-explosives"] = 400,
  
  -- Spidertron (extremadamente caro)
  ["spidertron"] = 5000,
  
  -- Planet-specific techs (muy caros)
  ["agricultural-science-pack"] = 2500,
  ["electromagnetic-science-pack"] = 2500,
  ["metallurgic-science-pack"] = 2500,
  ["cryogenic-science-pack"] = 3000,
  ["promethium-science-pack"] = 4000,
  
  -- Captive biter spawner (caro)
  ["captive-biter-spawner"] = 1000,
  
  -- Heating (moderado)
  ["heating"] = 600,
  
  -- Recycling (moderado)
  ["recycling"] = 400,
  
  -- Foundry (caro)
  ["foundry"] = 800,
  
  -- Big mining drill (caro)
  ["big-mining-drill"] = 1200,
  
  -- Electromagnetic plant (muy caro)
  ["electromagnetic-plant"] = 1500,
  
  -- Biolab (muy caro)
  ["biolab"] = 1800,
  
  -- Cryogenic plant (muy caro)
  ["cryogenic-plant"] = 2000,
  
  -- Fusion reactor (extremadamente caro)
  ["fusion-reactor"] = 8000,
  
  -- Mech armor (extremadamente caro)
  ["mech-armor"] = 6000
}

-- ===== ARREGLADO: SAFE INITIALIZATION FUNCTION - NO RESETEAR SAVES =====
function initialize_tde_global()
  if not global then
    global = {}
  end

  -- CRÍTICO: Solo inicializar si NO existe global.tde (partida nueva)
  if not global.tde then
    log("TDE: Creating NEW game - initializing fresh data")
    global.tde = {
      -- Kill tracking system - AJUSTADO para costos escalados
      total_kills = 80, -- Aumentado de 50 a 80 para gun-turret (35) + automation (10) + electronics (40)
      technologies_unlocked = {},
      
      -- Wave system
      wave_count = 0,
      next_wave_tick = game.tick + 1800,
      active_waves = {},
      boss_wave = false,
      
      -- Master Ammo Chest system
      master_ammo_chests = {},
      global_turrets = {},
      
      -- Resource system
      infinite_resources = {},
      
      -- Nest system with HP scaling
      nest_territories = {},
      
      -- Setup flag
      world_setup_complete = false,
      
      -- MAC reconstruction flag
      mac_needs_reconstruction = true
    }
    log("TDE: Initialized NEW global structure with starting kills")
  else
    log("TDE: EXISTING save detected - preserving all data")
    -- SOLO asegurar que tenga todas las propiedades necesarias sin cambiar valores
    if global.tde.total_kills == nil then global.tde.total_kills = 0 end
    if not global.tde.technologies_unlocked then global.tde.technologies_unlocked = {} end
    -- Only set wave_count if nil, never overwrite if it exists
    if global.tde.wave_count == nil then
      global.tde.wave_count = 0
      log("TDE: wave_count was nil, set to 0")
    else
      log("TDE: wave_count preserved: " .. tostring(global.tde.wave_count))
    end
    if not global.tde.active_waves then global.tde.active_waves = {} end
    if not global.tde.master_ammo_chests then global.tde.master_ammo_chests = {} end
    if not global.tde.global_turrets then global.tde.global_turrets = {} end
    if not global.tde.infinite_resources then global.tde.infinite_resources = {} end
    if not global.tde.nest_territories then global.tde.nest_territories = {} end
    if global.tde.world_setup_complete == nil then global.tde.world_setup_complete = false end
    if global.tde.mac_needs_reconstruction == nil then global.tde.mac_needs_reconstruction = false end

    -- CRÍTICO: NO tocar next_wave_tick si ya existe un valor válido
    if global.tde.next_wave_tick == nil then
      global.tde.next_wave_tick = game.tick + 1800
      log("TDE: Added missing next_wave_tick to existing save")
    else
      log("TDE: Preserving existing wave timing: " .. tostring(global.tde.next_wave_tick))
    end

    log("TDE: Preserved existing save - Kills: " .. global.tde.total_kills .. ", Wave: " .. global.tde.wave_count)
  end
end

-- ===== INITIALIZATION =====
script.on_init(function()
  log("TDE: on_init called - NEW GAME")
  initialize_tde_global()
  
  -- Print welcome message solo para partidas nuevas
  game.print("TOWER DEFENSE EVOLUTION - PURE KILLS SYSTEM")
  game.print("Kill biters to unlock technologies!")
  game.print("Waves every 10 minutes, boss every 10 waves!")
  game.print("Use Master Ammo Chests for automatic ammo distribution!")
end)

-- Handle migration for existing saves - TIMING CORREGIDO PARA MAC
script.on_configuration_changed(function(event)
  log("TDE: on_configuration_changed called - LOADING EXISTING SAVE")
  
  -- Solo verificar estructura sin resetear datos
  if not global or not global.tde then
    log("TDE: Missing global structure in existing save - initializing")
    initialize_tde_global()
  else
    log("TDE: Existing save loaded successfully")
    -- Solo añadir campos faltantes sin tocar valores existentes
    if global.tde.total_kills == nil then global.tde.total_kills = 0 end
    if not global.tde.technologies_unlocked then global.tde.technologies_unlocked = {} end
    if global.tde.wave_count == nil then global.tde.wave_count = 0 end
    if not global.tde.active_waves then global.tde.active_waves = {} end
    if not global.tde.master_ammo_chests then global.tde.master_ammo_chests = {} end
    if not global.tde.global_turrets then global.tde.global_turrets = {} end
    if not global.tde.infinite_resources then global.tde.infinite_resources = {} end
    if not global.tde.nest_territories then global.tde.nest_territories = {} end
    if global.tde.world_setup_complete == nil then global.tde.world_setup_complete = false end
    if global.tde.mac_needs_reconstruction == nil then global.tde.mac_needs_reconstruction = false end
    if not global.tde.next_wave_tick then 
      global.tde.next_wave_tick = game.tick + 1800 
    end
  end
  
  -- CRÍTICO: Marcar que necesita reconstruir MAC, pero no hacerlo ahora
  global.tde.mac_needs_reconstruction = true
  log("TDE: Marked MAC system for reconstruction on next game tick")
  
  -- Mostrar información de la partida cargada
  if global.tde then
    game.print("Tower Defense Evolution: Loaded existing save", {r = 0, g = 1, b = 1})
    game.print(string.format("Progress: %d kills | Wave: %d", 
      global.tde.total_kills or 0, global.tde.wave_count or 0), {r = 1, g = 1, b = 0})
    
    -- Mostrar tiempo hasta próxima wave
    if global.tde.next_wave_tick then
      local time_left = global.tde.next_wave_tick - game.tick
      if time_left > 0 then
        local minutes = math.floor(time_left / 3600)
        local seconds = math.floor((time_left % 3600) / 60)
        game.print(string.format("Next wave in: %d:%02d", minutes, seconds), {r = 0, g = 1, b = 1})
      else
        game.print("Wave incoming soon!", {r = 1, g = 0.8, b = 0})
      end
    end
    
    game.print("Rebuilding MAC system...", {r = 1, g = 1, b = 0})
  end
end)

-- NUEVA: Reconstrucción MAC ROBUSTA que encuentra TODAS las entidades
function reconstruct_mac_system_robust()
  log("TDE: Starting ROBUST MAC reconstruction...")
  
  if not global.tde then
    log("TDE: No global.tde found during reconstruction")
    return
  end
  
  -- Limpiar registros existentes completamente
  global.tde.master_ammo_chests = {}
  global.tde.global_turrets = {}
  
  -- Verificar que game y surfaces estén listos
  if not game or not game.surfaces then
    log("TDE: Game not ready for MAC reconstruction")
    return
  end
  
  local total_chest_count = 0
  local total_turret_count = 0
  
  -- Buscar en TODAS las superficies con manejo de errores robusto
  for surface_name, surface in pairs(game.surfaces) do
    if surface and surface.valid then
      log("TDE: Scanning surface " .. surface_name .. " for MAC entities")
      
      -- MEJORADO: Buscar Master Ammo Chests con múltiples intentos
      local chest_count = 0
      local success_chests, master_chests = pcall(function()
        return surface.find_entities_filtered({
          name = "master-ammo-chest"
        })
      end)
      
      if success_chests and master_chests then
        for _, chest in pairs(master_chests) do
          if chest and chest.valid and chest.unit_number then
            global.tde.master_ammo_chests[chest.unit_number] = {
              entity = chest,
              position = chest.position
            }
            chest_count = chest_count + 1
            log("TDE: Registered Master Ammo Chest " .. chest.unit_number .. " at " .. chest.position.x .. "," .. chest.position.y)
          end
        end
        total_chest_count = total_chest_count + chest_count
        log("TDE: Found " .. chest_count .. " Master Ammo Chests on " .. surface_name)
      else
        log("TDE: Error scanning for chests on " .. surface_name)
      end
      
      -- MEJORADO: Buscar torretas con detección exhaustiva
      local turret_count = 0
      local success_turrets, turrets = pcall(function()
        return surface.find_entities_filtered({
          type = {"ammo-turret", "electric-turret", "fluid-turret"}
        })
      end)
      
      if success_turrets and turrets then
        for _, turret in pairs(turrets) do
          if turret and turret.valid and turret.unit_number then
            local ammo_type = get_turret_ammo_type(turret)
            if ammo_type then -- Solo registrar torretas que necesitan munición
              global.tde.global_turrets[turret.unit_number] = {
                entity = turret,
                ammo_type = ammo_type,
                position = turret.position
              }
              turret_count = turret_count + 1
              log("TDE: Registered turret " .. turret.name .. " " .. turret.unit_number .. " at " .. turret.position.x .. "," .. turret.position.y)
            end
          end
        end
        total_turret_count = total_turret_count + turret_count
        log("TDE: Found " .. turret_count .. " turrets on " .. surface_name)
      else
        log("TDE: Error scanning for turrets on " .. surface_name)
      end
    end
  end
  
  log("TDE: ROBUST MAC reconstruction complete - " .. total_chest_count .. " chests, " .. total_turret_count .. " turrets total")
  
  -- Mensaje detallado al jugador
  if total_chest_count > 0 or total_turret_count > 0 then
    game.print(string.format("MAC system rebuilt: %d chests, %d turrets found and registered", 
      total_chest_count, total_turret_count), {r = 0, g = 1, b = 0})
  else
    game.print("No MAC entities found - place Master Ammo Chests and turrets!", {r = 1, g = 1, b = 0})
  end
end

-- ===== WORLD GENERATION =====
function setup_tower_defense_world()
  if not game.surfaces[1] or not game.surfaces[1].valid then
    log("No valid surface found during world setup")
    return
  end
  
  local surface = game.surfaces[1]
  
  -- Create small infinite resource patches (safe operation)
  local success1, error1 = pcall(create_small_infinite_patches, surface)
  if not success1 then
    log("Error creating resource patches: " .. tostring(error1))
  end
  
  -- Clear safe zone first
  local success2, error2 = pcall(clear_safe_zone, surface)
  if not success2 then
    log("Error clearing safe zone: " .. tostring(error2))
  end
  
  -- Generate initial nest field (reduced scope for better performance)
  local success3, error3 = pcall(generate_initial_nests, surface)
  if not success3 then
    log("Error generating initial nests: " .. tostring(error3))
  end
  
  -- Activate existing spawners
  activate_all_spawners(surface)
end

-- Activate all spawners to ensure they produce biters
function activate_all_spawners(surface)
  local spawners = surface.find_entities_filtered({
    name = {"biter-spawner", "spitter-spawner"}
  })
  
  for _, spawner in pairs(spawners) do
    if spawner and spawner.valid then
      spawner.active = true
      -- Store in nest territories for defensive behavior
      if spawner.unit_number and global.tde and global.tde.nest_territories then
        global.tde.nest_territories[spawner.unit_number] = {
          spawner = spawner,
          position = spawner.position,
          distance = math.sqrt(spawner.position.x^2 + spawner.position.y^2),
          is_defensive = true,
          spawn_cooldown = 0
        }
      end
    end
  end
  
  log("Activated " .. #spawners .. " existing spawners")
end

-- Simplified initial nest generation
function generate_initial_nests(surface)
  if not surface or not surface.valid then
    log("Invalid surface in generate_initial_nests")
    return
  end
  
  if not global.tde or not global.tde.nest_territories then
    log("Global TDE structure not ready for nest generation")
    return
  end
  
  -- Generate only a few nests initially in a small area
  local max_range = 250  -- Very small initial range
  local nest_count = 0
  local max_nests = 30   -- More initial nests for better gameplay
  
  for x = -max_range, max_range, 25 do
    for y = -max_range, max_range, 25 do
      if nest_count >= max_nests then break end
      
      local distance = math.sqrt(x*x + y*y)
      
      -- Skip safe zone and place sparsely
      if distance > SAFE_ZONE_RADIUS and distance < max_range and math.random() < 0.4 then
        local position = {x = x + math.random(-12, 12), y = y + math.random(-12, 12)}
        
        local success, created = pcall(create_scaled_nest, surface, position, distance)
        if success and created then
          nest_count = nest_count + 1
        end
      end
    end
    if nest_count >= max_nests then break end
  end
  
  log("Initial nest generation completed: " .. nest_count .. " nests created")
end

function create_small_infinite_patches(surface)
  if not surface or not surface.valid then
    log("Invalid surface in create_small_infinite_patches")
    return
  end
  
  if not global.tde or not global.tde.infinite_resources then
    log("Global TDE structure not ready for infinite resources")
    return
  end
  
  local resources = {
    {name = "iron-ore", pos = {x = 20, y = 0}, amount = 2000000},
    {name = "copper-ore", pos = {x = -20, y = 0}, amount = 2000000},
    {name = "coal", pos = {x = 0, y = 20}, amount = 1500000},
    {name = "stone", pos = {x = 0, y = -20}, amount = 1000000},
    {name = "uranium-ore", pos = {x = 30, y = 30}, amount = 800000}
  }
  
  -- Create oil separately with different handling
  local oil_success, oil = pcall(function()
    return surface.create_entity({
      name = "crude-oil",
      position = {x = -30, y = -30},
      amount = 50000000
    })
  end)
  
  if oil_success and oil and oil.valid then
    local oil_id = oil.unit_number
    if oil_id then
      global.tde.infinite_resources[oil_id] = {
        entity = oil,
        base_amount = 50000000,
        resource_name = "crude-oil",
        is_oil = true
      }
      log("Created oil patch successfully")
    else
      log("Oil entity has no unit_number")
    end
  else
    log("Failed to create oil entity")
  end
  
  -- Create resource patches
  for _, resource_info in pairs(resources) do
    for x = -1, 1 do
      for y = -1, 1 do
        local pos = {
          x = resource_info.pos.x + x,
          y = resource_info.pos.y + y
        }
        
        local success, resource = pcall(function()
          return surface.create_entity({
            name = resource_info.name,
            position = pos,
            amount = resource_info.amount
          })
        end)
        
        if success and resource and resource.valid then
          local resource_id = resource.unit_number
          if resource_id then
            global.tde.infinite_resources[resource_id] = {
              entity = resource,
              base_amount = resource_info.amount,
              resource_name = resource_info.name
            }
          else
            log("Resource entity has no unit_number: " .. resource_info.name)
          end
        else
          log("Failed to create resource: " .. resource_info.name .. " at " .. pos.x .. "," .. pos.y)
        end
      end
    end
  end
  
  log("Resource patch creation completed")
end

-- Safe spawner creation without prototype access
function create_scaled_nest(surface, position, distance)
  if not surface or not surface.valid then
    return false
  end
  
  local valid_position = surface.find_non_colliding_position("biter-spawner", position, 15, 1)
  if not valid_position then return false end
  
  -- Mix of biter and spitter spawners (70% biter, 30% spitter)
  local spawner_type = "biter-spawner"
  if math.random() < 0.3 then
    spawner_type = "spitter-spawner"
  end
  
  local success, spawner = pcall(function()
    return surface.create_entity({
      name = spawner_type,
      position = valid_position,
      force = "enemy"
    })
  end)
  
  if success and spawner and spawner.valid then
    -- Use fixed HP bonus instead of prototype access
    local base_hp = 500 -- Fixed base HP for spawners
    local hp_bonus = math.min(distance / 10, MAX_DISTANCE_HP / 10)
    local new_health = math.min(base_hp + hp_bonus, spawner.health + hp_bonus)
    spawner.health = new_health
    
    -- IMPORTANT: Make spawner active
    spawner.active = true
    
    -- Store for tracking with defensive capability
    if global.tde and global.tde.nest_territories then
      global.tde.nest_territories[spawner.unit_number] = {
        spawner = spawner,
        position = valid_position,
        distance = distance,
        hp_bonus = hp_bonus,
        is_defensive = true,  -- Enable defensive spawning
        spawn_cooldown = 0
      }
    end
    
    return true
  end
  
  return false
end

function clear_safe_zone(surface)
  if not surface or not surface.valid then
    log("Invalid surface in clear_safe_zone")
    return
  end
  
  local success, enemies = pcall(function()
    return surface.find_entities_filtered({
      area = {{-SAFE_ZONE_RADIUS, -SAFE_ZONE_RADIUS}, {SAFE_ZONE_RADIUS, SAFE_ZONE_RADIUS}},
      force = "enemy"
    })
  end)
  
  if success and enemies then
    local cleared_count = 0
    for _, enemy in pairs(enemies) do
      if enemy and enemy.valid then
        local destroy_success = pcall(function() enemy.destroy() end)
        if destroy_success then
          cleared_count = cleared_count + 1
        end
      end
    end
    log("Cleared " .. cleared_count .. " enemies from safe zone")
  else
    log("Failed to find enemies in safe zone")
  end
end

-- ===== KILL-BASED TECHNOLOGY SYSTEM =====
function get_tech_kill_cost(technology)
  -- Use local table instead of prototype access
  if TECH_KILL_COSTS[technology.name] then
    return TECH_KILL_COSTS[technology.name]
  end
  
  -- Fallback calculation based on technology name patterns - ESCALADOS
  local base_cost = 150 -- Aumentado de 50 a 150
  if string.find(technology.name, "-2") then
    base_cost = 300   -- Aumentado de 100 a 300
  elseif string.find(technology.name, "-3") then
    base_cost = 600   -- Aumentado de 200 a 600
  elseif string.find(technology.name, "-4") then
    base_cost = 900   -- Aumentado de 300 a 900
  elseif string.find(technology.name, "-5") then
    base_cost = 1200  -- Aumentado de 400 a 1200
  elseif string.find(technology.name, "-6") then
    base_cost = 1500  -- Aumentado de 500 a 1500
  elseif string.find(technology.name, "-7") then
    base_cost = 1800  -- Aumentado de 600 a 1800
  end
  
  -- Adjust by technology type - MULTIPLICADORES ESCALADOS
  if string.find(technology.name, "military") or 
     string.find(technology.name, "weapon") or 
     string.find(technology.name, "armor") or
     string.find(technology.name, "damage") or
     string.find(technology.name, "turret") then
    base_cost = base_cost * 1.5  -- Aumentado de 1.2 a 1.5
  end
  
  if string.find(technology.name, "space") or
     string.find(technology.name, "rocket") or
     string.find(technology.name, "planet") then
    base_cost = base_cost * 8  -- Aumentado de 5 a 8
  end
  
  if string.find(technology.name, "productivity") or
     string.find(technology.name, "mining") then
    base_cost = base_cost * 2  -- Aumentado de 1.5 a 2
  end
  
  return math.max(25, math.ceil(base_cost))  -- Mínimo aumentado de 10 a 25
end

function can_research_technology(technology)
  if not technology or not technology.valid or technology.researched then
    return false
  end
  
  -- Check prerequisites
  for _, prereq in pairs(technology.prerequisites) do
    if not prereq.researched then
      return false
    end
  end
  
  -- Check if we have enough kills
  local required_kills = get_tech_kill_cost(technology)
  return global.tde.total_kills >= required_kills
end

-- Handle research attempts
script.on_event(defines.events.on_research_started, function(event)
  local technology = event.research
  if not technology or not technology.valid then return end
  
  -- Get kill cost
  local required_kills = get_tech_kill_cost(technology)
  
  -- Check if we can afford it
  if global.tde.total_kills >= required_kills then
    -- Check prerequisites
    local prereqs_met = true
    for _, prereq in pairs(technology.prerequisites) do
      if not prereq.researched then
        prereqs_met = false
        game.print(string.format("Missing prerequisite: %s", prereq.localised_name and prereq.localised_name[1] or prereq.name), {r = 1, g = 0.5, b = 0})
        break
      end
    end
    
    if prereqs_met then
      -- Deduct kills and allow research to complete
      global.tde.total_kills = global.tde.total_kills - required_kills
      global.tde.technologies_unlocked[technology.name] = true
      
      game.print(string.format("Technology unlocked: %s (Cost: %d kills)", 
        technology.localised_name and technology.localised_name[1] or technology.name, required_kills), {r = 0, g = 1, b = 0})
      
      -- Let the research complete normally since we've modified the tech tree in data-final-fixes
    else
      -- Cancel research if prerequisites not met
      technology.force.cancel_current_research()
    end
  else
    -- Cancel research if not enough kills
    technology.force.cancel_current_research()
    game.print(string.format("Not enough kills! Need %d kills, have %d kills", 
      required_kills, global.tde.total_kills), {r = 1, g = 0, b = 0})
  end
end)

-- Print tech costs on GUI open
script.on_event(defines.events.on_gui_opened, function(event)
  if event.gui_type == defines.gui_type.research then
    -- Print available technologies and their costs
    game.print("=== AVAILABLE TECHNOLOGIES ===", {r = 0, g = 1, b = 1})
    
    local available_techs = {}
    for _, tech in pairs(game.forces.player.technologies) do
      if tech and tech.valid and not tech.researched then
        -- Check prerequisites
        local prereqs_met = true
        for _, prereq in pairs(tech.prerequisites) do
          if not prereq.researched then
            prereqs_met = false
            break
          end
        end
        
        if prereqs_met then
          local cost = get_tech_kill_cost(tech)
          table.insert(available_techs, {name = tech.name, cost = cost, tech = tech})
        end
      end
    end
    
    -- Sort by cost
    table.sort(available_techs, function(a, b) return a.cost < b.cost end)
    
    -- Show first 20 cheapest available techs
    for i = 1, math.min(20, #available_techs) do
      local tech_info = available_techs[i]
      local status = global.tde.total_kills >= tech_info.cost and "AFFORDABLE" or "TOO EXPENSIVE"
      local display_name = tech_info.tech.localised_name and tech_info.tech.localised_name[1] or tech_info.name
      game.print(string.format("  %s: %d kills (%s)", display_name, tech_info.cost, status))
    end
    
    game.print(string.format("Your kills: %d | Available techs: %d", global.tde.total_kills, #available_techs))
    
    if #available_techs == 0 then
      game.print("No technologies available - check prerequisites or earn more kills!", {r = 1, g = 0.8, b = 0})
    end
  end
end)

-- ===== KILL TRACKING =====
script.on_event(defines.events.on_entity_died, function(event)
  local entity = event.entity
  if not entity or not entity.valid then return end
  
  -- Track biter kills with better feedback
  if entity.force.name == "enemy" and entity.type == "unit" then
    global.tde.total_kills = global.tde.total_kills + 1
    
    -- Show kill counter with technology hints
    if global.tde.total_kills % 25 == 0 then
      local available_count = 0
      for _, tech in pairs(game.forces.player.technologies) do
        if can_research_technology(tech) then
          available_count = available_count + 1
        end
      end
      
      game.print(string.format("Kills: %d | Available techs: %d", 
        global.tde.total_kills, available_count), {r = 1, g = 0.8, b = 0})
      
      if available_count > 0 then
        game.print("Open Research tab to unlock technologies!", {r = 0, g = 1, b = 0.5})
      end
    end
  end
  
  -- Handle boss kills with special value
  if entity.unit_number and global.tde.nest_territories[entity.unit_number] then
    local nest_data = global.tde.nest_territories[entity.unit_number]
    if nest_data.is_boss then
      global.tde.total_kills = global.tde.total_kills + nest_data.kill_value
      game.print(string.format("BOSS DEFEATED! +%d kills! Total: %d", 
        nest_data.kill_value, global.tde.total_kills), {r = 1, g = 0, b = 1})
      global.tde.nest_territories[entity.unit_number] = nil
    end
  end
  
  -- Handle Master Ammo Chest system
  if entity.name == "master-ammo-chest" then
    unregister_master_ammo_chest(entity)
  elseif is_turret(entity) then
    unregister_turret(entity)
  end
end)

-- ===== WAVE SYSTEM =====
function schedule_first_wave()
  global.tde.next_wave_tick = game.tick + 1800 -- 30 seconds initial delay
  game.print("First wave incoming in 30 seconds!", {r = 1, g = 0.8, b = 0})
end

-- AÑADIR función nueva que monitorea cambios en wave_count:
function monitor_wave_count_changes(location)
  if global and global.tde then
    log("TDE: Wave count check at " .. location .. " - Current: " .. tostring(global.tde.wave_count))
  else
    log("TDE: Wave count check at " .. location .. " - global.tde is nil!")
  end
end

-- ARREGLADO: Main game loop - RECONSTRUCCIÓN MAC AUTOMÁTICA Y ROBUSTA + MONITOREO
script.on_nth_tick(60, function(event) 
  monitor_wave_count_changes("main_loop_start")
  
  -- CRÍTICO: Verificar que global existe
  if not global or not global.tde then
    log("TDE: CRITICAL - Global missing in main loop, calling initialize_tde_global()")
    monitor_wave_count_changes("before_init")
    initialize_tde_global()
    monitor_wave_count_changes("after_init")
    return
  end
  
  -- Verificación de integridad
  if not global.tde.wave_count then
    log("TDE: CRITICAL - wave_count is nil, setting to 0")
    global.tde.wave_count = 0
  end
  
  monitor_wave_count_changes("after_integrity_check")
  
  -- CRÍTICO: Reconstruir MAC system si está marcado para reconstrucción (PRIORITARIO)
  if global.tde.mac_needs_reconstruction then
    log("TDE: Executing automatic MAC reconstruction...")
    reconstruct_mac_system_robust()
    global.tde.mac_needs_reconstruction = false
    log("TDE: MAC reconstruction completed")
    
    -- Mostrar mensaje al jugador
    game.print("MAC system automatically rebuilt!", {r = 0, g = 1, b = 0})
    return -- Salir para procesar en el siguiente tick
  end
  
  -- Handle delayed world setup on first run (solo para partidas nuevas con wave_count = 0)
  if not global.tde.world_setup_complete and global.tde.wave_count == 0 then
    local success, error_msg = pcall(function()
      setup_tower_defense_world()
      global.tde.world_setup_complete = true
    end)
    
    if success then
      game.print("World setup completed successfully!")
    else
      log("Error during world setup: " .. tostring(error_msg))
      game.print("Warning: World setup encountered errors. Check log for details.")
      global.tde.world_setup_complete = true -- Prevent infinite retries
    end
    return
  end
  
  -- NUEVO: Verificación automática de integridad MAC cada 2 minutos
  if game.tick % 7200 == 0 then
    verify_and_fix_mac_system()
  end
  
  monitor_wave_count_changes("before_game_operations")
  
  -- Normal game operations
  check_wave_schedule()
  manage_active_waves()
  process_ammo_distribution()
  
  -- Balancear munición entre torretas cada 30 segundos
  if game.tick % 1800 == 0 then
    balance_ammo_between_turrets()
  end
  
  -- Expand nest field every 10 minutes (reduced frequency to prevent crashes)
  if game.tick % 36000 == 0 and global.tde.wave_count > 0 then
    expand_nest_field()
  end
  
  -- Periodically ensure spawners are active
  if game.tick % 1800 == 0 then -- Every 30 seconds
    ensure_spawners_active()
  end
  
  -- Calculate wave state from game tick
  local calculated_wave, calculated_next_wave_tick = tde_calculate_wave_state()
  global.tde.wave_count = calculated_wave
  global.tde.next_wave_tick = calculated_next_wave_tick

  monitor_wave_count_changes("main_loop_end")
end)

-- Ensure spawners remain active
function ensure_spawners_active()
  if not game.surfaces[1] or not game.surfaces[1].valid then return end
  
  local surface = game.surfaces[1]
  local spawners = surface.find_entities_filtered({
    name = {"biter-spawner", "spitter-spawner"}
  })
  
  local activated_count = 0
  for _, spawner in pairs(spawners) do
    if spawner and spawner.valid and not spawner.active then
      spawner.active = true
      activated_count = activated_count + 1
    end
  end
  
  if activated_count > 0 then
    log("Reactivated " .. activated_count .. " dormant spawners")
  end
end

-- Gradually expand nest field during gameplay
function expand_nest_field()
  if not game.surfaces[1] or not game.surfaces[1].valid then
    return
  end
  
  local surface = game.surfaces[1]
  local current_range = 350 + (global.tde.wave_count * 20) -- Slower expansion
  
  -- Add only a few nests at a time to prevent performance issues
  local nest_count = 4 + math.random(0, 3) -- 4-7 nests per expansion
  
  for i = 1, nest_count do
    local angle = math.random() * 2 * math.pi
    local distance = current_range + math.random(-40, 40)
    
    if distance > SAFE_ZONE_RADIUS then
      local position = {
        x = math.cos(angle) * distance,
        y = math.sin(angle) * distance
      }
      
      -- Only create nest if area is not too crowded
      local nearby_spawners = surface.count_entities_filtered({
        name = {"biter-spawner", "spitter-spawner"},
        position = position,
        radius = 60
      })
      
      if nearby_spawners < 2 then -- Limit density
        local success = create_scaled_nest(surface, position, distance)
        if success then
          log("Created new nest at distance: " .. distance)
        end
      end
    end
  end
  
  log("Expanded nest field to range: " .. current_range .. " (attempted " .. nest_count .. " nests)")
end

function check_wave_schedule()
  -- Use calculated next_wave_tick
  if game.tick >= global.tde.next_wave_tick then
    spawn_wave()
    -- No need to schedule_next_wave, as it's calculated from tick
  end
end

function spawn_wave()
  -- Use calculated wave_count
  local wave_num = global.tde.wave_count
  log("TDE: spawn_wave() called - Wave: " .. tostring(wave_num))
  game.print("DEBUG: Wave incremented to " .. wave_num, {r = 0, g = 1, b = 1})

  local is_boss_wave = (wave_num % BOSS_EVERY == 0 and wave_num > 0)

  if is_boss_wave then
    spawn_boss_wave()
  else
    spawn_normal_wave()
  end
end

function spawn_normal_wave()
  -- BALANCEADO: Empezar con waves pequeñas y escalar gradualmente
  local wave_size
  if global.tde.wave_count == 1 then
    wave_size = 5  -- Primera wave: solo 5 biters
  elseif global.tde.wave_count <= 5 then
    wave_size = 5 + global.tde.wave_count * 3  -- Waves 2-5: 8, 11, 14, 17, 20
  else
    wave_size = 20 + (global.tde.wave_count - 5) * 2  -- Waves 6+: escalado normal
  end
  
  local evolution = get_enemy_evolution()
  
  local composition = calculate_wave_composition(wave_size, evolution)
  local spawn_locations = find_wave_spawn_locations()
  
  -- CORREGIDO: Seleccionar solo UNA dirección para la wave, no todas
  local selected_spawn = spawn_locations[math.random(#spawn_locations)]
  
  if selected_spawn then
    create_attack_group(selected_spawn.position, composition, false, selected_spawn)
    
    game.print(string.format("Wave %d incoming! (%d biters)", 
      global.tde.wave_count, wave_size), {r = 1, g = 0, b = 0})
  end
end

function spawn_boss_wave()
  local boss_kills_value = math.floor((global.tde.wave_count / BOSS_EVERY) * 1000)
  
  -- Create boss composition
  local boss_composition = {["behemoth-biter"] = 1}
  local escort_size = 8 + global.tde.wave_count / 4
  local escort_composition = calculate_wave_composition(escort_size, 0.9)
  
  local spawn_locations = find_wave_spawn_locations()
  
  -- CORREGIDO: Boss desde UNA dirección específica
  local boss_spawn = spawn_locations[math.random(#spawn_locations)]
  
  if boss_spawn then
    -- Spawn boss
    create_attack_group(boss_spawn.position, boss_composition, true, boss_spawn, boss_kills_value)
    
    -- Spawn escorts desde la misma dirección pero posiciones ligeramente diferentes
    local escort_position = {
      x = boss_spawn.position.x + math.random(-50, 50),
      y = boss_spawn.position.y + math.random(-50, 50)
    }
    create_attack_group(escort_position, escort_composition, false, boss_spawn)
    
    game.print(string.format("BOSS WAVE %d! Behemoth leader worth %d kills!", 
      global.tde.wave_count, boss_kills_value), {r = 1, g = 0, b = 1})
  end
end

function calculate_wave_composition(base_count, evolution)
  local composition = {}
  
  if evolution < 0.2 then
    composition["small-biter"] = math.floor(base_count * 0.7)
    composition["small-spitter"] = math.floor(base_count * 0.3)
  elseif evolution < 0.5 then
    composition["small-biter"] = math.floor(base_count * 0.3)
    composition["medium-biter"] = math.floor(base_count * 0.4)
    composition["medium-spitter"] = math.floor(base_count * 0.3)
  elseif evolution < 0.8 then
    composition["medium-biter"] = math.floor(base_count * 0.2)
    composition["big-biter"] = math.floor(base_count * 0.5)
    composition["big-spitter"] = math.floor(base_count * 0.3)
  else
    composition["big-biter"] = math.floor(base_count * 0.3)
    composition["behemoth-biter"] = math.floor(base_count * 0.4)
    composition["behemoth-spitter"] = math.floor(base_count * 0.3)
  end
  
  return composition
end

function find_wave_spawn_locations()
  local surface = game.surfaces[1]
  local spawn_distance = 450 + global.tde.wave_count * 3
  local locations = {}
  
  -- Direcciones con nombres y flechas para el chat
  local directions = {
    {angle = 0, name = "Este", arrow = "→", direction = "east"},           -- Este  
    {angle = math.pi/2, name = "Sur", arrow = "↓", direction = "south"},    -- Sur
    {angle = math.pi, name = "Oeste", arrow = "←", direction = "west"},     -- Oeste
    {angle = 3*math.pi/2, name = "Norte", arrow = "↑", direction = "north"} -- Norte
  }
  
  for _, dir_info in pairs(directions) do
    local spawn_point = {
      x = math.cos(dir_info.angle) * spawn_distance,
      y = math.sin(dir_info.angle) * spawn_distance
    }
    
    local valid_position = surface.find_non_colliding_position("big-biter", spawn_point, 60, 5)
    if valid_position then
      table.insert(locations, {
        position = valid_position,
        direction = dir_info.direction,
        name = dir_info.name,
        arrow = dir_info.arrow
      })
    end
  end
  
  return locations
end

function create_attack_group(spawn_point, composition, is_boss, spawn_info, boss_kill_value)
  local surface = game.surfaces[1]
  
  local unit_group = surface.create_unit_group({
    position = spawn_point,
    force = game.forces.enemy
  })
  
  for unit_type, count in pairs(composition) do
    for i = 1, count do
      local unit_position = {
        x = spawn_point.x + math.random(-20, 20),
        y = spawn_point.y + math.random(-20, 20)
      }
      
      local valid_position = surface.find_non_colliding_position(unit_type, unit_position, 25, 3)
      if valid_position then
        local unit = surface.create_entity({
          name = unit_type,
          position = valid_position,
          force = game.forces.enemy
        })
        
        if unit and unit.valid then
          -- Apply boss modifications
          if is_boss and unit_type == "behemoth-biter" and boss_kill_value then
            -- Get current health and multiply to 10 for boss
            local current_health = unit.health
            unit.health = current_health * 10 -- 10x health for boss
            
            -- Store boss kill value
            local unit_id = unit.unit_number
            if unit_id and global.tde and global.tde.nest_territories then
              global.tde.nest_territories[unit_id] = {
                is_boss = true,
                kill_value = boss_kill_value
              }
            end
          end
          
          unit_group.add_member(unit)
        end
      end
    end
  end
  
  -- MEJORADO: Pathfinding más agresivo hacia la base del jugador
  local player_base = find_player_base_center()
  
  if player_base then
    -- Comando más directo y agresivo
    unit_group.set_command({
      type = defines.command.attack_area,
      destination = player_base,
      radius = 100, -- Radio más pequeño para ser más agresivo
      distraction = defines.distraction.by_enemy -- Solo se distraen por enemigos, no por estructuras
    })
  else
    -- Fallback: ataque directo al spawn
    unit_group.set_command({
      type = defines.command.attack_area,
      destination = {x = 0, y = 0},
      radius = 150,
      distraction = defines.distraction.by_enemy
    })
  end
  
  -- CORREGIDO: Anunciar dirección solo una vez y con la información correcta
  if spawn_info and spawn_info.name and spawn_info.arrow then
    local boss_prefix = is_boss and "BOSS " or ""
    game.print(string.format("%s%s %s %s Attack incoming!", 
      boss_prefix, spawn_info.arrow, spawn_info.name, spawn_info.arrow), {r = 1, g = 0.5, b = 0})
  end
  
  table.insert(global.tde.active_waves, {
    group = unit_group,
    spawn_time = game.tick,
    wave_number = global.tde.wave_count,
    is_boss = is_boss or false,
    destination = player_base or {x = 0, y = 0},
    direction = spawn_info and spawn_info.direction
  })
end

function find_player_base_center()
  local surface = game.surfaces[1]
  
  -- Look for key player structures
  local player_entities = surface.find_entities_filtered({
    force = "player",
    type = {"assembling-machine", "furnace", "lab", "rocket-silo", "ammo-turret", "electric-turret", "inserter", "transport-belt", "container", "logistic-container"}
  })
  
  if #player_entities > 0 then
    local total_x, total_y = 0, 0
    for _, entity in pairs(player_entities) do
      total_x = total_x + entity.position.x
      total_y = total_y + entity.position.y
    end
    
    local center = {
      x = total_x / #player_entities,
      y = total_y / #player_entities
    }
    
    log("Player base center found at: " .. center.x .. ", " .. center.y)
    return center
  end
  
  -- Fallback: look for player position
  for _, player in pairs(game.players) do
    if player.valid and player.character then
      log("Using player position as base center: " .. player.position.x .. ", " .. player.position.y)
      return player.position
    end
  end
  
  log("No player base found, using spawn")
  return {x = 0, y = 0}
end

function manage_active_waves()
  local active_waves = {}
  
  for _, wave_data in pairs(global.tde.active_waves) do
    if wave_data.group.valid and #wave_data.group.members > 0 then
      table.insert(active_waves, wave_data)
    else
      if wave_data.group.valid and #wave_data.group.members == 0 then
        local wave_type = wave_data.is_boss and "BOSS " or ""
        game.print(string.format("%sWave %d defeated!", wave_type, wave_data.wave_number), {r = 0, g = 1, b = 0})
      end
    end
  end
  
  global.tde.active_waves = active_waves
end

-- ===== MASTER AMMO CHEST SYSTEM - CORREGIDO =====
script.on_event(defines.events.on_built_entity, function(event)
  local entity = event.created_entity or event.entity
  if not entity or not entity.valid then return end
  
  if entity.name == "master-ammo-chest" then
    register_master_ammo_chest(entity)
  elseif is_turret(entity) then
    register_turret(entity)
  end
end)

script.on_event(defines.events.on_robot_built_entity, function(event)
  local entity = event.created_entity
  if not entity or not entity.valid then return end
  
  if entity.name == "master-ammo-chest" then
    register_master_ammo_chest(entity)
  elseif is_turret(entity) then
    register_turret(entity)
  end
end)

function register_master_ammo_chest(chest)
  if not chest or not chest.valid or not chest.unit_number then
    log("Cannot register master ammo chest - invalid entity")
    return
  end
  
  global.tde.master_ammo_chests[chest.unit_number] = {
    entity = chest,
    position = chest.position
  }
  
  game.print("Master Ammo Chest registered for global distribution!", {r = 0, g = 1, b = 0})
  log("Registered Master Ammo Chest at " .. chest.position.x .. "," .. chest.position.y)
end

function unregister_master_ammo_chest(chest)
  if chest and chest.unit_number then
    global.tde.master_ammo_chests[chest.unit_number] = nil
    log("Unregistered Master Ammo Chest")
  end
end

function register_turret(turret)
  if not turret or not turret.valid or not turret.unit_number then
    log("Cannot register turret - invalid entity")
    return
  end
  
  local ammo_type = get_turret_ammo_type(turret)
  if ammo_type then
    global.tde.global_turrets[turret.unit_number] = {
      entity = turret,
      ammo_type = ammo_type,
      position = turret.position
    }
    log("Registered turret " .. turret.name .. " at " .. turret.position.x .. "," .. turret.position.y .. " (needs " .. ammo_type .. ")")
    game.print("Turret registered: " .. turret.name .. " (needs " .. ammo_type .. ")", {r = 0, g = 1, b = 0.5})
  else
    log("Turret " .. turret.name .. " doesn't need ammo - not registered")
  end
end

function unregister_turret(turret)
  if turret and turret.unit_number then
    global.tde.global_turrets[turret.unit_number] = nil
    log("Unregistered turret")
  end
end

function is_turret(entity)
  return entity.type == "ammo-turret" or entity.type == "electric-turret" or entity.type == "fluid-turret"
end

function get_turret_ammo_type(turret)
  if turret.name == "gun-turret" then
    return "firearm-magazine"
  elseif turret.name == "laser-turret" then
    return nil -- Laser turrets don't need ammo
  elseif turret.name == "flamethrower-turret" then
    return nil -- Flamethrower turrets use fluid, not ammo
  end
  return nil
end

-- CORREGIDO: Sistema de distribución de munición SIMPLIFICADO - Volver a lógica que funcionaba
function process_ammo_distribution()
  if game.tick % 180 ~= 0 then return end -- Every 3 seconds
  
  if not global.tde or not global.tde.master_ammo_chests or not global.tde.global_turrets then
    return
  end
  
  -- Limpiar torretas inválidas primero
  local valid_turret_count = 0
  for turret_id, turret_data in pairs(global.tde.global_turrets) do
    if turret_data.entity and turret_data.entity.valid and turret_data.ammo_type then
      valid_turret_count = valid_turret_count + 1
    else
      global.tde.global_turrets[turret_id] = nil
    end
  end
  
  -- Si no hay torretas válidas, no hacer nada (no tocar cofres)
  if valid_turret_count == 0 then
    -- Debug cada minuto
    if game.tick % 3600 == 0 then
      log("MAC System: No valid turrets found, skipping ammo collection")
    end
    return
  end
  
  local total_ammo = {}
  local chest_count = 0
  
  -- Recoger munición de Master Ammo Chests (solo si hay torretas válidas)
  for chest_id, chest_data in pairs(global.tde.master_ammo_chests) do
    if chest_data.entity and chest_data.entity.valid then
      chest_count = chest_count + 1
      local inventory = chest_data.entity.get_inventory(defines.inventory.chest)
      
      if inventory then
        for i = 1, #inventory do
          local stack = inventory[i]
          if stack.valid_for_read and is_ammunition(stack.name) then
            total_ammo[stack.name] = (total_ammo[stack.name] or 0) + stack.count
            stack.clear()
          end
        end
      end
    else
      global.tde.master_ammo_chests[chest_id] = nil
      log("Removed invalid Master Ammo Chest " .. chest_id)
    end
  end
  
  -- Debug output every minute
  if game.tick % 3600 == 0 and (chest_count > 0 or valid_turret_count > 0) then
    log(string.format("MAC System: %d chests, %d turrets registered", chest_count, valid_turret_count))
    for ammo_name, count in pairs(total_ammo) do
      log(string.format("  Collected %d %s", count, ammo_name))
    end
  end
  
  -- Distribuir munición (usar función original simplificada)
  if next(total_ammo) then
    distribute_ammo_to_turrets_simple(total_ammo)
  end
end

-- CORREGIDO: Función is_ammunition mejorada
function is_ammunition(item_name)
  if not item_name then return false end
  
  -- Hardcoded ammunition types para evitar problemas con prototypes
  local ammo_types = {
    ["firearm-magazine"] = true,
    ["piercing-rounds-magazine"] = true,
    ["uranium-rounds-magazine"] = true,
    ["shotgun-shell"] = true,
    ["piercing-shotgun-shell"] = true,
    ["cannon-shell"] = true,
    ["explosive-cannon-shell"] = true,
    ["uranium-cannon-shell"] = true,
    ["explosive-uranium-cannon-shell"] = true,
    ["artillery-shell"] = true,
    ["rocket"] = true,
    ["explosive-rocket"] = true,
    ["atomic-bomb"] = true,
    ["flamethrower-ammo"] = true
  }
  
  return ammo_types[item_name] or false
end

function distribute_ammo_to_turrets_simple(total_ammo)
  if not total_ammo or not next(total_ammo) then
    return
  end
  
  local turret_groups = {}
  
  -- Agrupar torretas válidas por tipo de munición
  for turret_id, turret_data in pairs(global.tde.global_turrets) do
    if turret_data.entity and turret_data.entity.valid and turret_data.ammo_type then
      local ammo_type = turret_data.ammo_type
      turret_groups[ammo_type] = turret_groups[ammo_type] or {}
      table.insert(turret_groups[ammo_type], turret_data)
    end
  end
  
  -- Distribuir cada tipo de munición
  for ammo_name, total_count in pairs(total_ammo) do
    local compatible_turrets = find_compatible_turrets(ammo_name, turret_groups)
    
    if #compatible_turrets > 0 then
      local ammo_per_turret = math.floor(total_count / #compatible_turrets)
      local distributed_count = 0
      
      for _, turret_data in pairs(compatible_turrets) do
        if turret_data.entity and turret_data.entity.valid and ammo_per_turret > 0 then
          local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
          if inventory then
            local inserted = inventory.insert({name = ammo_name, count = ammo_per_turret})
            distributed_count = distributed_count + inserted
          end
        end
      end
      
      if distributed_count > 0 then
        game.print(string.format("Distributed %d %s to %d turrets", 
          distributed_count, ammo_name, #compatible_turrets), {r = 0, g = 0.8, b = 1})
      end
    else
      log("No compatible turrets found for " .. ammo_name .. " - this shouldn't happen")
    end
  end
end

-- NUEVA: Verificación automática e integridad del sistema MAC
function verify_and_fix_mac_system()
  if not global.tde or not global.tde.master_ammo_chests or not global.tde.global_turrets then
    return
  end
  
  local invalid_chests = 0
  local invalid_turrets = 0
  
  -- Verificar chests y limpiar inválidos
  for chest_id, chest_data in pairs(global.tde.master_ammo_chests) do
    if not chest_data.entity or not chest_data.entity.valid then
      invalid_chests = invalid_chests + 1
      global.tde.master_ammo_chests[chest_id] = nil
    end
  end
  
  -- Verificar turrets y limpiar inválidos
  for turret_id, turret_data in pairs(global.tde.global_turrets) do
    if not turret_data.entity or not turret_data.entity.valid then
      invalid_turrets = invalid_turrets + 1
      global.tde.global_turrets[turret_id] = nil
    end
  end
  
  -- Si se perdieron muchas entidades, reconstruir automáticamente
  if invalid_chests > 3 or invalid_turrets > 10 then
    log("TDE: Too many invalid entities detected - auto-rebuilding MAC system")
    global.tde.mac_needs_reconstruction = true
    game.print("MAC system integrity check failed - rebuilding automatically...", {r = 1, g = 0.8, b = 0})
  elseif invalid_chests > 0 or invalid_turrets > 0 then
    log(string.format("TDE: MAC integrity check - removed %d invalid chests, %d invalid turrets", 
      invalid_chests, invalid_turrets))
  end
end

-- ARREGLADO: Sistema de balanceo de munición entre torretas - SIMPLIFICADO Y FUNCIONAL
function balance_ammo_between_turrets()
  if not global.tde or not global.tde.global_turrets then
    return
  end
  
  log("TDE: Starting ammo balancing...")
  
  -- Agrupar torretas por tipo de munición
  local turret_groups = {}
  local total_turrets = 0
  
  for turret_id, turret_data in pairs(global.tde.global_turrets) do
    if turret_data.entity and turret_data.entity.valid and turret_data.ammo_type then
      local ammo_type = turret_data.ammo_type
      turret_groups[ammo_type] = turret_groups[ammo_type] or {}
      table.insert(turret_groups[ammo_type], turret_data)
      total_turrets = total_turrets + 1
    else
      global.tde.global_turrets[turret_id] = nil
    end
  end
  
  if total_turrets == 0 then
    return
  end
  
  log("TDE: Found " .. total_turrets .. " turrets to balance")
  
  -- Balancear cada grupo de torretas
  local total_redistributed = 0
  for ammo_type, turrets in pairs(turret_groups) do
    if #turrets > 1 then -- Solo balancear si hay más de 1 torreta
      local redistributed = balance_ammo_group_simple(turrets, ammo_type)
      total_redistributed = total_redistributed + redistributed
    end
  end
  
  if total_redistributed > 0 then
    game.print(string.format("Rebalanced %d ammo among turrets", total_redistributed), {r = 0, g = 0.8, b = 1})
    log("TDE: Ammo balancing completed - redistributed " .. total_redistributed .. " ammo")
  end
end

-- NUEVA: Función de balanceo SIMPLE que SÍ funciona
function balance_ammo_group_simple(turrets, ammo_type)
  local turret_inventories = {}
  local total_ammo = 0
  
  -- Paso 1: Recopilar información de todas las torretas
  for _, turret_data in pairs(turrets) do
    if turret_data.entity and turret_data.entity.valid then
      local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
      if inventory then
        local ammo_count = 0
        
        -- Contar munición total en esta torreta
        for i = 1, #inventory do
          local stack = inventory[i]
          if stack.valid_for_read then
            ammo_count = ammo_count + stack.count
          end
        end
        
        table.insert(turret_inventories, {
          turret_data = turret_data,
          inventory = inventory,
          current_ammo = ammo_count
        })
        total_ammo = total_ammo + ammo_count
      end
    end
  end
  
  if #turret_inventories < 2 or total_ammo == 0 then
    return 0 -- No hay suficientes torretas o munición para balancear
  end
  
  -- Paso 2: Calcular si hay desequilibrio significativo
  local max_ammo = 0
  local min_ammo = math.huge
  
  for _, turret_inv in pairs(turret_inventories) do
    max_ammo = math.max(max_ammo, turret_inv.current_ammo)
    min_ammo = math.min(min_ammo, turret_inv.current_ammo)
  end
  
  local difference = max_ammo - min_ammo
  log("TDE: Ammo difference: " .. difference .. " (max: " .. max_ammo .. ", min: " .. min_ammo .. ")")
  
  -- Solo balancear si hay una diferencia significativa (más de 15 municiones)
  if difference < 15 then
    log("TDE: Difference too small, skipping balance")
    return 0
  end
  
  -- Paso 3: Redistribución simple - mover munición de torretas con más a torretas con menos
  local redistributed = 0
  local target_ammo = math.floor(total_ammo / #turret_inventories)
  
  -- Recoger exceso de torretas que tienen más que el promedio + 5
  local excess_ammo_items = {}
  
  for _, turret_inv in pairs(turret_inventories) do
    if turret_inv.current_ammo > target_ammo + 5 then
      local excess = turret_inv.current_ammo - target_ammo
      local removed = 0
      
      -- Remover munición excedente
      for i = 1, #turret_inv.inventory do
        local stack = turret_inv.inventory[i]
        if stack.valid_for_read and removed < excess then
          local to_remove = math.min(excess - removed, stack.count)
          
          -- Guardar munición removida
          table.insert(excess_ammo_items, {
            name = stack.name,
            count = to_remove
          })
          
          stack.count = stack.count - to_remove
          removed = removed + to_remove
          redistributed = redistributed + to_remove
          
          if stack.count == 0 then
            stack.clear()
          end
        end
      end
    end
  end
  
  -- Distribuir munición excedente a torretas que tienen menos que el promedio - 5
  for _, turret_inv in pairs(turret_inventories) do
    if turret_inv.current_ammo < target_ammo - 5 and #excess_ammo_items > 0 then
      local needed = target_ammo - turret_inv.current_ammo
      
      -- Dar munición de la reserva de exceso
      for i = #excess_ammo_items, 1, -1 do
        local ammo_item = excess_ammo_items[i]
        if needed > 0 and ammo_item.count > 0 then
          local to_give = math.min(needed, ammo_item.count)
          local inserted = turret_inv.inventory.insert({name = ammo_item.name, count = to_give})
          
          ammo_item.count = ammo_item.count - inserted
          needed = needed - inserted
          
          if ammo_item.count == 0 then
            table.remove(excess_ammo_items, i)
          end
        end
      end
    end
  end
  
  log("TDE: Redistributed " .. redistributed .. " " .. ammo_type .. " ammo")
  return redistributed
end

function find_compatible_turrets(ammo_name, turret_groups)
  local ammo_compatibility = {
    ["firearm-magazine"] = "firearm-magazine",
    ["piercing-rounds-magazine"] = "firearm-magazine",
    ["uranium-rounds-magazine"] = "firearm-magazine"
  }
  
  local compatible_type = ammo_compatibility[ammo_name]
  return (compatible_type and turret_groups[compatible_type]) or {}
end

-- ===== RESOURCE REPLENISHMENT =====
script.on_event(defines.events.on_resource_depleted, function(event)
  if not event.entity or not event.entity.valid or not event.entity.unit_number then
    return
  end
  
  local resource_data = global.tde.infinite_resources[event.entity.unit_number]
  
  if resource_data then
    event.entity.amount = resource_data.base_amount
    
    event.entity.surface.create_entity({
      name = "flying-text",
      position = event.entity.position,
      text = "Replenished",
      color = {r = 0, g = 1, b = 0}
    })
  end
end)

-- ===== NEST ACTIVATION SYSTEM =====
script.on_event(defines.events.on_entity_damaged, function(event)
  if not event.entity or not event.entity.valid then return end
  
  if event.entity.name == "biter-spawner" or event.entity.name == "spitter-spawner" then
    local spawner_id = event.entity.unit_number
    if spawner_id and global.tde and global.tde.nest_territories then
      local nest_data = global.tde.nest_territories[spawner_id]
      
      if nest_data and nest_data.is_defensive then
        activate_defensive_nest(nest_data, event.cause)
      end
    end
  end
end)

function activate_defensive_nest(nest_data, attacker)
  local current_tick = game.tick
  
  -- Check cooldown
  if current_tick < (nest_data.spawn_cooldown or 0) then
    return
  end
  
  nest_data.spawn_cooldown = current_tick + 1200 -- 20 second cooldown
  nest_data.last_attacked = current_tick
  
  game.print("Nest under attack! Spawning defenders!", {r = 1, g = 0.5, b = 0})
  
  spawn_defensive_units(nest_data, attacker)
  alert_nearby_nests(nest_data.position, 150)
end

function spawn_defensive_units(nest_data, attacker)
  if not nest_data.spawner or not nest_data.spawner.valid then
    return
  end
  
  local surface = nest_data.spawner.surface
  local evolution = get_enemy_evolution()
  
  local distance_from_spawn = math.sqrt(nest_data.position.x^2 + nest_data.position.y^2)
  local distance_factor = math.min(1.5, distance_from_spawn / 1000)
  
  local base_count = 4 + math.floor(evolution * 5) + math.floor(distance_factor * 3)
  local composition = calculate_defensive_composition(evolution, base_count)
  
  -- CORREGIDO: Crear unit_group para comando en lugar de unidades individuales
  local unit_group = surface.create_unit_group({
    position = nest_data.position,
    force = game.forces.enemy
  })
  
  local units_spawned = 0
  
  for unit_type, count in pairs(composition) do
    for i = 1, count do
      local spawn_angle = math.random() * 2 * math.pi
      local spawn_distance = math.random(10, 18)
      local spawn_position = {
        x = nest_data.position.x + math.cos(spawn_angle) * spawn_distance,
        y = nest_data.position.y + math.sin(spawn_angle) * spawn_distance
      }
      
      local valid_position = surface.find_non_colliding_position(unit_type, spawn_position, 15, 2)
      if valid_position then
        local unit = surface.create_entity({
          name = unit_type,
          position = valid_position,
          force = game.forces.enemy
        })
        
        if unit and unit.valid then
          units_spawned = units_spawned + 1
          unit_group.add_member(unit)
        end
      end
    end
  end
  
  -- CORREGIDO: Dar comando al group, no a unidades individuales
  if units_spawned > 0 then
    if attacker and attacker.valid then
      unit_group.set_command({
        type = defines.command.attack,
        target = attacker,
        distraction = defines.distraction.by_anything
      })
    else
      -- Attack towards player base if no specific attacker
      local player_base = find_player_base_center()
      unit_group.set_command({
        type = defines.command.attack_area,
        destination = player_base or {x = 0, y = 0},
        radius = 75,
        distraction = defines.distraction.by_anything
      })
    end
    
    -- Create explosion effect
    surface.create_entity({
      name = "explosion",
      position = nest_data.position
    })
    
    log("Spawned " .. units_spawned .. " defensive units at nest")
  end
end

function calculate_defensive_composition(evolution, base_count)
  local composition = {}
  
  if evolution < 0.2 then
    composition["small-biter"] = math.floor(base_count * 0.7)
    composition["small-spitter"] = math.floor(base_count * 0.3)
  elseif evolution < 0.5 then
    composition["small-biter"] = math.floor(base_count * 0.3)
    composition["medium-biter"] = math.floor(base_count * 0.4)
    composition["medium-spitter"] = math.floor(base_count * 0.3)
  elseif evolution < 0.8 then
    composition["medium-biter"] = math.floor(base_count * 0.2)
    composition["big-biter"] = math.floor(base_count * 0.5)
    composition["big-spitter"] = math.floor(base_count * 0.3)
  else
    composition["big-biter"] = math.floor(base_count * 0.3)
    composition["behemoth-biter"] = math.floor(base_count * 0.4)
    composition["behemoth-spitter"] = math.floor(base_count * 0.3)
  end
  
  return composition
end

function alert_nearby_nests(position, radius)
  local surface = game.surfaces[1]
  
  local nearby_spawners = surface.find_entities_filtered({
    area = {{position.x - radius, position.y - radius}, {position.x + radius, position.y + radius}},
    name = {"biter-spawner", "spitter-spawner"},
    force = "enemy"
  })
  
  for _, spawner in pairs(nearby_spawners) do
    if spawner.unit_number then
      local nest_data = global.tde.nest_territories[spawner.unit_number]
      if nest_data and nest_data.is_defensive then
        local current_tick = game.tick
        
        if current_tick >= (nest_data.spawn_cooldown or 0) and math.random() < 0.3 then
          nest_data.spawn_cooldown = current_tick + 2400
          
          -- CORREGIDO: Pasar nest_data completo, no crear nuevo objeto
          spawn_defensive_units(nest_data, nil)
        end
      end
    end
  end
end

-- ===== DISABLE POLLUTION ATTACKS =====
script.on_event(defines.events.on_chunk_generated, function(event)
  -- Find all spawners and make them active but not pollution responsive
  local spawners = event.surface.find_entities_filtered({
    area = event.area,
    name = {"biter-spawner", "spitter-spawner"}
  })
  
  for _, spawner in pairs(spawners) do
    spawner.active = true -- Keep spawners active for natural spawning
    
    -- Register in our system
    if spawner.unit_number and global.tde and global.tde.nest_territories then
      global.tde.nest_territories[spawner.unit_number] = {
        spawner = spawner,
        position = spawner.position,
        distance = math.sqrt(spawner.position.x^2 + spawner.position.y^2),
        is_defensive = true,
        spawn_cooldown = 0
      }
    end
  end
end)

-- ===== DEBUG COMMANDS =====
commands.add_command("tde-add-kills", "Add kills for testing (number)", function(command)
  local amount = tonumber(command.parameter) or 100
  global.tde.total_kills = global.tde.total_kills + amount
  game.print(string.format("Added %d kills. Total: %d", amount, global.tde.total_kills))
  
  -- Show available techs count
  local available_count = 0
  for _, tech in pairs(game.forces.player.technologies) do
    if can_research_technology(tech) then
      available_count = available_count + 1
    end
  end
  
  if available_count > 0 then
    game.print(string.format("%d technologies now available for research!", available_count), {r = 0, g = 1, b = 0})
  end
end)

commands.add_command("tde-wave", "Spawn test wave", function(command)
  spawn_wave()
end)

commands.add_command("tde-status", "Show current status", function(command)
  local next_wave_seconds = math.floor((global.tde.next_wave_tick - game.tick) / 60)
  local next_wave_minutes = math.floor(next_wave_seconds / 60)
  
  game.print("=== TOWER DEFENSE EVOLUTION STATUS ===", {r = 0, g = 1, b = 1})
  game.print(string.format("Kills: %d | Wave: %d | Next: %d:%02d", 
    global.tde.total_kills, 
    global.tde.wave_count,
    next_wave_minutes, next_wave_seconds % 60))
  
  -- Información detallada del estado
  game.print(string.format("Game tick: %d | Next wave tick: %d", 
    game.tick, global.tde.next_wave_tick))
  
  game.print(string.format("Active waves: %d | World setup: %s", 
    #global.tde.active_waves, global.tde.world_setup_complete and "Complete" or "Pending"))
    
  -- Show some tech costs
  local sample_techs = {"automation", "electronics", "logistics", "military", "gun-turret", "laser-turrets"}
  game.print("Sample technology costs:")
  for _, tech_name in pairs(sample_techs) do
    local tech = game.forces.player.technologies[tech_name]
    if tech then
      local cost = get_tech_kill_cost(tech)
      local status = tech.researched and "RESEARCHED" or "AVAILABLE"
      game.print(string.format("  %s: %d kills (%s)", tech_name, cost, status))
    end
  end
end)

commands.add_command("tde-tech", "Unlock technology by name", function(command)
  local tech_name = command.parameter
  if not tech_name then
    game.print("Usage: /tde-tech <technology-name>")
    return
  end
  
  local tech = game.forces.player.technologies[tech_name]
  if not tech then
    game.print("Technology not found: " .. tech_name)
    return
  end
  
  if tech.researched then
    game.print("Technology already researched: " .. tech_name)
    return
  end
  
  local required_kills = get_tech_kill_cost(tech)
  
  if global.tde.total_kills >= required_kills then
    -- Check prerequisites
    local can_research = true
    for _, prereq in pairs(tech.prerequisites) do
      if not prereq.researched then
        can_research = false
        game.print(string.format("Missing prerequisite: %s", prereq.name), {r = 1, g = 0.5, b = 0})
        break
      end
    end
    
    if can_research then
      global.tde.total_kills = global.tde.total_kills - required_kills
      tech.researched = true
      game.print(string.format("Technology unlocked: %s", tech_name), {r = 0, g = 1, b = 0})
    end
  else
    game.print(string.format("Not enough kills! Need %d, have %d", required_kills, global.tde.total_kills))
  end
end)

commands.add_command("tde-tech-debug", "Debug technology system", function(command)
  game.print("=== TECHNOLOGY SYSTEM DEBUG ===")
  game.print("Current kills: " .. global.tde.total_kills)
  
  local test_techs = {"automation", "electronics", "logistics", "military", "gun-turret", "laser-turrets"}
  
  for _, tech_name in pairs(test_techs) do
    local tech = game.forces.player.technologies[tech_name]
    if tech then
      local cost = get_tech_kill_cost(tech)
      local status = tech.researched and "RESEARCHED" or "AVAILABLE"
      local affordable = global.tde.total_kills >= cost and "YES" or "NO"
      local prereqs_met = true
      
      for _, prereq in pairs(tech.prerequisites) do
        if not prereq.researched then
          prereqs_met = false
          break
        end
      end
      
      game.print(string.format("  %s: %d kills | %s | Can afford: %s | Prereqs: %s", 
        tech_name, cost, status, affordable, prereqs_met and "YES" or "NO"))
    else
      game.print("  " .. tech_name .. ": NOT FOUND")
    end
  end
  
  game.print("Open Research tab to see all available technologies!")
end)

commands.add_command("tde-nest-test", "Test nest defense system", function(command)
  local player = game.players[1]
  if not player then 
    game.print("No player found")
    return 
  end
  
  -- Find nearest spawner
  local spawners = player.surface.find_entities_filtered({
    name = {"biter-spawner", "spitter-spawner"},
    position = player.position,
    radius = 300
  })
  
  if #spawners > 0 then
    local spawner = spawners[1]
    local spawner_id = spawner.unit_number
    if spawner_id and global.tde.nest_territories[spawner_id] then
      local nest_data = global.tde.nest_territories[spawner_id]
      
      -- CORREGIDO: Verificar que nest_data tiene toda la información necesaria
      if not nest_data.spawner then
        nest_data.spawner = spawner
      end
      if not nest_data.position then
        nest_data.position = spawner.position
      end
      
      game.print("Activating nest defense test...")
      log("Nest test: spawner valid=" .. tostring(nest_data.spawner and nest_data.spawner.valid))
      
      activate_defensive_nest(nest_data, player.character)
      game.print("Activated nearest nest defense!")
    else
      game.print("Nearest spawner not registered in nest system")
      log("Spawner ID: " .. tostring(spawner_id) .. ", registered: " .. tostring(global.tde.nest_territories[spawner_id] ~= nil))
    end
  else
    game.print("No spawners found nearby")
  end
end)

commands.add_command("tde-spawners", "Check spawner status", function(command)
  if not game.surfaces[1] then return end
  
  local spawners = game.surfaces[1].find_entities_filtered({
    name = {"biter-spawner", "spitter-spawner"}
  })
  
  local active_count = 0
  local inactive_count = 0
  
  for _, spawner in pairs(spawners) do
    if spawner.active then
      active_count = active_count + 1
    else
      inactive_count = inactive_count + 1
      spawner.active = true -- Reactivate
    end
  end
  
  game.print(string.format("Spawners: %d active, %d reactivated, %d total", 
    active_count, inactive_count, #spawners))
end)

-- MEJORADO: Comando para debug de guardado/carga con más info sobre wave_count
commands.add_command("tde-save-debug", "Debug save/load system", function(command)
  game.print("=== SAVE/LOAD DEBUG v11 ===", {r = 1, g = 1, b = 0})
  game.print("Global structure exists: " .. tostring(global ~= nil))
  game.print("TDE data exists: " .. tostring(global and global.tde ~= nil))
  
  if global and global.tde then
    game.print("--- CURRENT DATA ---")
    game.print("Total kills: " .. tostring(global.tde.total_kills))
    game.print("Wave count: " .. tostring(global.tde.wave_count))
    game.print("Next wave tick: " .. tostring(global.tde.next_wave_tick))
    game.print("Current game tick: " .. tostring(game.tick))
    game.print("Time to next wave: " .. tostring(global.tde.next_wave_tick - game.tick) .. " ticks")
    game.print("World setup complete: " .. tostring(global.tde.world_setup_complete))
    game.print("Technologies unlocked: " .. tostring(global.tde.technologies_unlocked and table_size(global.tde.technologies_unlocked) or 0))
    game.print("Master ammo chests: " .. tostring(global.tde.master_ammo_chests and table_size(global.tde.master_ammo_chests) or 0))
    game.print("Global turrets: " .. tostring(global.tde.global_turrets and table_size(global.tde.global_turrets) or 0))
    game.print("Active waves: " .. tostring(#global.tde.active_waves))
    
    -- NUEVO: Debug específico para wave_count
    game.print("--- WAVE DEBUG INFO ---")
    game.print("Wave count type: " .. type(global.tde.wave_count))
    if global.tde.wave_count then
      game.print("Wave count value: " .. global.tde.wave_count)
      if global.tde.wave_count > 0 then
        game.print("Wave count is POSITIVE - save should preserve this!", {r = 0, g = 1, b = 0})
      else
        game.print("Wave count is ZERO - might be new game or reset", {r = 1, g = 0.8, b = 0})
      end
    else
      game.print("Wave count is NIL - this is a bug!", {r = 1, g = 0, b = 0})
    end
  else
    game.print("ERROR: No TDE data found!", {r = 1, g = 0, b = 0})
  end
end)

-- MEJORADO: Comando de reconstrucción manual más informativo
commands.add_command("tde-mac-rebuild", "Manually rebuild MAC system", function(command)
  game.print("Rebuilding Master Ammo Chest system...", {r = 1, g = 1, b = 0})
  reconstruct_mac_system_robust()
  game.print("MAC system rebuild complete!", {r = 0, g = 1, b = 0})
  
  -- Mostrar estadísticas después de la reconstrucción
  local chest_count = 0
  local turret_count = 0
  
  for _ in pairs(global.tde.master_ammo_chests) do
    chest_count = chest_count + 1
  end
  
  for _ in pairs(global.tde.global_turrets) do
    turret_count = turret_count + 1
  end
  
  game.print(string.format("Result: %d chests, %d turrets registered", chest_count, turret_count))
end)

-- Helper function para table_size
function table_size(t)
  local count = 0
  if t then
    for _ in pairs(t) do count = count + 1 end
  end
  return count
end

-- NUEVO comando de debug para rastrear el problema de wave_count
commands.add_command("tde-wave-debug", "Debug wave count issues", function(command)
  game.print("=== WAVE COUNT DEBUG ===", {r = 1, g = 1, b = 0})
  
  if not global then
    game.print("ERROR: global is nil!", {r = 1, g = 0, b = 0})
    return
  end
  
  if not global.tde then
    game.print("ERROR: global.tde is nil!", {r = 1, g = 0, b = 0})
    return
  end
  
  game.print("Current wave_count: " .. tostring(global.tde.wave_count))
  game.print("Current total_kills: " .. tostring(global.tde.total_kills))
  game.print("Current game tick: " .. tostring(game.tick))
  game.print("Next wave tick: " .. tostring(global.tde.next_wave_tick))
  
  if global.tde.next_wave_tick then
    local time_left = global.tde.next_wave_tick - game.tick
    game.print("Time to next wave: " .. tostring(time_left) .. " ticks")
    
    if time_left > 0 then
      local minutes = math.floor(time_left / 3600)
      local seconds = math.floor((time_left % 3600) / 60)
      game.print("That's: " .. minutes .. ":" .. string.format("%02d", seconds))
    end
  end
  
  game.print("World setup complete: " .. tostring(global.tde.world_setup_complete))
  game.print("Active waves: " .. tostring(#global.tde.active_waves))
end)

commands.add_command("tde-mac-debug", "Debug Master Ammo Chest system", function(command)
  game.print("=== MASTER AMMO CHEST DEBUG v11 ===")
  
  local chest_count = 0
  local total_ammo_in_chests = {}
  local invalid_chest_count = 0
  
  for chest_id, chest_data in pairs(global.tde.master_ammo_chests) do
    if chest_data.entity and chest_data.entity.valid then
      chest_count = chest_count + 1
      local pos = chest_data.position
      local inventory = chest_data.entity.get_inventory(defines.inventory.chest)
      local ammo_count = 0
      
      if inventory then
        for i = 1, #inventory do
          local stack = inventory[i]
          if stack.valid_for_read and is_ammunition(stack.name) then
            ammo_count = ammo_count + stack.count
            total_ammo_in_chests[stack.name] = (total_ammo_in_chests[stack.name] or 0) + stack.count
          end
        end
      end
      
      game.print(string.format("  Chest %d at (%d,%d) - %d ammo items", 
        chest_id, pos.x, pos.y, ammo_count))
    else
      invalid_chest_count = invalid_chest_count + 1
      global.tde.master_ammo_chests[chest_id] = nil
    end
  end
  
  local valid_turret_count = 0
  local invalid_turret_count = 0
  
  for turret_id, turret_data in pairs(global.tde.global_turrets) do
    if turret_data.entity and turret_data.entity.valid and turret_data.ammo_type then
      valid_turret_count = valid_turret_count + 1
      local pos = turret_data.position
      
      -- Verificar cuánta munición tiene la torreta
      local turret_ammo = 0
      local inventory = turret_data.entity.get_inventory(defines.inventory.turret_ammo)
      if inventory then
        for i = 1, #inventory do
          local stack = inventory[i]
          if stack.valid_for_read then
            turret_ammo = turret_ammo + stack.count
          end
        end
      end
      
      game.print(string.format("  Turret %d (%s) at (%d,%d) - needs %s, has %d ammo", 
        turret_id, turret_data.entity.name, pos.x, pos.y, turret_data.ammo_type, turret_ammo))
    else
      invalid_turret_count = invalid_turret_count + 1
      global.tde.global_turrets[turret_id] = nil
    end
  end
  
  game.print(string.format("Total: %d valid chests (%d invalid), %d valid turrets (%d invalid)", 
    chest_count, invalid_chest_count, valid_turret_count, invalid_turret_count))
  
  for ammo_name, count in pairs(total_ammo_in_chests) do
    game.print(string.format("  Available: %d %s", count, ammo_name))
  end
  
  -- Diagnóstico de estado del sistema
  if chest_count > 0 and valid_turret_count == 0 then
    game.print("WARNING: Chests will NOT consume ammo because no valid turrets!", {r = 1, g = 0.5, b = 0})
  elseif chest_count > 0 and valid_turret_count > 0 then
    game.print("System working correctly - ammo will be distributed!", {r = 0, g = 1, b = 0})
  elseif chest_count == 0 and valid_turret_count > 0 then
    game.print("No Master Ammo Chests found - place some to enable auto-distribution!", {r = 1, g = 1, b = 0})
  else
    game.print("No MAC system components found - place chests and turrets!", {r = 1, g = 0.8, b = 0})
  end
  
  -- Opción de reconstrucción manual
  game.print("Use /tde-mac-rebuild to manually reconstruct the system", {r = 0, g = 0.8, b = 1})
end)

-- ===== PLAYER WELCOME AND STARTING EQUIPMENT =====
script.on_event(defines.events.on_player_joined_game, function(event)
  local player = game.get_player(event.player_index)
  if not player then return end
  
  -- Give starting equipment - Only ammunition
  if player.character then
    local inventory = player.get_main_inventory()
    if inventory then
      -- Only ammunition, no weapons or grenades
      inventory.insert({name = "firearm-magazine", count = 500})
      inventory.insert({name = "piercing-rounds-magazine", count = 200})
    end
  end
  
  player.print("=== TOWER DEFENSE EVOLUTION - PURE KILLS SYSTEM ===")
  player.print("Kill biters to unlock technologies!")
  player.print("Waves every 10 minutes, boss every 10 waves!")
  player.print("Build Master Ammo Chests for automatic distribution!")
  player.print("Expand to secure more resource patches!")
  player.print("Open Research tab (T) to see available technologies!")
  
  if global.tde then
    player.print(string.format("Starting kills: %d (enough for basics!)", global.tde.total_kills), {r = 0, g = 1, b = 0})
    
    -- Listar tecnologías inmediatamente disponibles con los nuevos costos
    local immediate_techs = {"automation (10)", "gun-turret (35)", "logistics (25)", "military (30)", "electronics (40)"}
    player.print("Immediately available: " .. table.concat(immediate_techs, ", "), {r = 1, g = 1, b = 0})
  end
end)

-- ===== SAFE EVOLUTION FACTOR ACCESS =====
function get_enemy_evolution()
  local success, evolution = pcall(function()
    return game.forces.enemy.get_evolution_factor()
  end)
  
  if success and evolution then
    return evolution
  else
    -- Fallback calculation based on time if API fails
    local game_time_hours = game.tick / 216000 -- Convert ticks to hours
    return math.min(game_time_hours * 0.1, 1.0) -- 10% per hour, max 100%
  end
end

function tde_get_wave_interval_ticks()
  -- Get the runtime-global setting for wave interval (in minutes)
  local minutes = 10
  if settings and settings.global and settings.global["tde-wave-interval"] then
    minutes = settings.global["tde-wave-interval"].value or 10
  end
  return minutes * 60 * 60
end

function tde_calculate_wave_state()
  -- Always at least wave 0 at tick 0
  local elapsed = game.tick
  local wave_interval = tde_get_wave_interval_ticks()
  local wave = math.floor(elapsed / wave_interval)
  local next_wave_tick = (wave + 1) * wave_interval
  return wave, next_wave_tick
end