-- Final fixes - Complete technology overhaul and turret buffs
-- VERSION 4.0.0 v3 - TORRES BALANCEADAS, GUI TECH TREE CON KILL COSTS ESCALADOS

log("TDE: Starting technology overhaul in data-final-fixes v3")

-- COMPLETE TECHNOLOGY COSTS DATABASE (duplicada para usar en data stage) - ESCALADOS
local TECH_KILL_COSTS = {
  -- Starting techs (accesible al inicio)
  ["automation"] = 10,
  ["logistics"] = 25,
  ["military"] = 30,
  ["electronics"] = 40,
  
  -- Basic production (baratos pero no triviales)
  ["steel-processing"] = 80,
  ["fast-inserter"] = 120,
  ["long-handed-inserter"] = 100,
  ["filter-inserter"] = 180,
  ["stack-inserter"] = 300,
  ["bulk-inserter"] = 450,
  
  -- Military techs (moderados pero importantes)
  ["gun-turret"] = 35,  -- Mantener barato para inicio
  ["stone-walls"] = 50,
  ["gates"] = 80,
  ["military-2"] = 150,
  ["military-3"] = 400,
  ["military-4"] = 800,
  ["laser-turrets"] = 500,  -- Mucho más caro
  ["flamethrower"] = 350,
  ["land-mine"] = 120,
  ["defender"] = 250,
  ["distractor"] = 500,
  ["destroyer"] = 800,
  
  -- Space and endgame (extremadamente caros)
  ["rocket-silo"] = 3000,
  ["space-science-pack"] = 2500,
  ["satellite"] = 2000,
  ["space-platform"] = 4000,
  ["space-platform-foundation"] = 3000,
  ["cargo-bay"] = 2500,
  ["asteroid-reprocessing"] = 3500,
  ["space-platform-thruster"] = 2800,
  ["planet-discovery-vulcanus"] = 5000,
  ["planet-discovery-gleba"] = 5000,
  ["planet-discovery-fulgora"] = 5000,
  ["planet-discovery-aquilo"] = 6000,
  
  -- Advanced production (caros)
  ["advanced-electronics"] = 200,
  ["advanced-electronics-2"] = 500,
  ["engine"] = 250,
  ["oil-processing"] = 300,
  ["plastics"] = 250,
  ["chemistry"] = 400,
  ["advanced-oil-processing"] = 600,
  ["nuclear-power"] = 1500,
  ["nuclear-fuel"] = 1000,
  
  -- Logistics (escalados)
  ["logistics-2"] = 300,
  ["logistics-3"] = 600,
  ["construction-robotics"] = 500,
  ["logistic-robotics"] = 450,
  ["robotics"] = 400,
  
  -- High-tier production (muy caros)
  ["electric-furnace"] = 400,
  ["productivity-module"] = 600,
  ["speed-module"] = 500,
  ["efficiency-module"] = 450,
  ["productivity-module-2"] = 1200,
  ["speed-module-2"] = 1000,
  ["efficiency-module-2"] = 900,
  ["productivity-module-3"] = 2400,
  ["speed-module-3"] = 2000,
  ["efficiency-module-3"] = 1800,
  
  -- Weapons escalados progresivamente
  ["physical-projectile-damage-1"] = 200,
  ["physical-projectile-damage-2"] = 350,
  ["physical-projectile-damage-3"] = 500,
  ["physical-projectile-damage-4"] = 700,
  ["physical-projectile-damage-5"] = 900,
  ["physical-projectile-damage-6"] = 1200,
  ["physical-projectile-damage-7"] = 1500,
  
  ["laser-weapons-damage-1"] = 300,
  ["laser-weapons-damage-2"] = 500,
  ["laser-weapons-damage-3"] = 800,
  ["laser-weapons-damage-4"] = 1100,
  ["laser-weapons-damage-5"] = 1400,
  ["laser-weapons-damage-6"] = 1700,
  ["laser-weapons-damage-7"] = 2000,
  
  -- Turret damage upgrades (escalados)
  ["physical-projectile-damage-for-turrets-1"] = 300,
  ["physical-projectile-damage-for-turrets-2"] = 500,
  ["physical-projectile-damage-for-turrets-3"] = 800,
  ["laser-turret-damage-1"] = 400,
  ["laser-turret-damage-2"] = 600,
  ["laser-turret-damage-3"] = 900,
  ["laser-turret-damage-4"] = 1200,
  ["laser-turret-damage-5"] = 1500,
  ["laser-turret-damage-6"] = 1800,
  ["laser-turret-damage-7"] = 2100,
  
  -- Otros importantes
  ["spidertron"] = 5000,
  ["artillery"] = 2000,
  ["fusion-reactor"] = 8000,
  ["mech-armor"] = 6000
}

-- Add a fake science pack for kills (for GUI display)
data:extend({
  {
    type = "tool",
    name = "tde-kill-token",
    icon = "__base__/graphics/icons/small-biter-corpse.png", -- Use vanilla biter corpse icon, or replace with your own
    icon_size = 64,
    icon_mipmaps = 4,
    subgroup = "science-pack",
    order = "z[tde-kill-token]",
    stack_size = 1,
    durability = 1,
    durability_description_key = "description.science-pack-remaining-amount",
    localised_name = {"item-name.tde-kill-token"},
    localised_description = {"item-description.tde-kill-token"}
  }
})

-- Modify technologies to show kill costs in GUI and remove science pack requirements
local function calculate_fallback_kill_cost(tech_name)
  local base_cost = 150
  if string.find(tech_name, "-2") then
    base_cost = 300
  elseif string.find(tech_name, "-3") then
    base_cost = 600
  elseif string.find(tech_name, "-4") then
    base_cost = 900
  elseif string.find(tech_name, "-5") then
    base_cost = 1200
  elseif string.find(tech_name, "-6") then
    base_cost = 1500
  elseif string.find(tech_name, "-7") then
    base_cost = 1800
  end

  if string.find(tech_name, "military") or 
     string.find(tech_name, "weapon") or 
     string.find(tech_name, "armor") or
     string.find(tech_name, "damage") or
     string.find(tech_name, "turret") then
    base_cost = base_cost * 1.5
  end

  if string.find(tech_name, "space") or
     string.find(tech_name, "rocket") or
     string.find(tech_name, "planet") then
    base_cost = base_cost * 8
  end

  if string.find(tech_name, "productivity") or
     string.find(tech_name, "mining") then
    base_cost = base_cost * 2
  end

  return math.max(25, math.ceil(base_cost))
end

for tech_name, tech in pairs(data.raw.technology) do
  if tech then
    -- Get kill cost for this technology
    local kill_cost = TECH_KILL_COSTS[tech_name] or calculate_fallback_kill_cost(tech_name)

    -- Use the fake kill token as the only ingredient (must be type "tool")
    tech.unit = {
      count = kill_cost,
      ingredients = {{"tde-kill-token", 1}},
      time = 1
    }
    
    -- Asegurar que la tecnología esté habilitada
    if tech.enabled ~= nil then
      tech.enabled = true
    end
    
    -- Agregar descripción del costo en kills si no tiene descripción personalizada
    if not tech.localised_description then
      tech.localised_description = {"", "Cost: " .. kill_cost .. " kills"}
    end
    
    log("TDE: Modified technology " .. tech_name .. " - cost: " .. kill_cost .. " kills")
  end
end

-- ===== BALANCE TURRETS FOR TOWER DEFENSE - NERFEAR UN POCO =====
if data.raw["ammo-turret"] and data.raw["ammo-turret"]["gun-turret"] then
  local gun_turret = data.raw["ammo-turret"]["gun-turret"]
  gun_turret.max_health = 800         -- Reducido de 1000 a 800
  gun_turret.inventory_size = 15      -- Reducido de 20 a 15 
  if gun_turret.attack_parameters then
    gun_turret.attack_parameters.range = 30    -- Reducido de 35 a 30
    gun_turret.attack_parameters.cooldown = 6  -- Aumentado de 4 a 6 (más lento)
  end
  log("TDE: Balanced gun turret (nerfed slightly)")
end

if data.raw["electric-turret"] and data.raw["electric-turret"]["laser-turret"] then
  local laser_turret = data.raw["electric-turret"]["laser-turret"]
  laser_turret.max_health = 1200      -- Reducido de 1500 a 1200
  if laser_turret.attack_parameters then
    laser_turret.attack_parameters.range = 35  -- Reducido de 38 a 35
    laser_turret.attack_parameters.cooldown = 25  -- Aumentado de 20 a 25
  end
  if laser_turret.energy_source then
    laser_turret.energy_source.buffer_capacity = "1200kJ"  -- Reducido de 1500kJ
  end
  log("TDE: Balanced laser turret (nerfed slightly)")
end

-- Buff flamethrower turret if it exists
if data.raw["fluid-turret"] and data.raw["fluid-turret"]["flamethrower-turret"] then
  local flame_turret = data.raw["fluid-turret"]["flamethrower-turret"]
  flame_turret.max_health = 1000      -- Reducido de 1200 a 1000
  if flame_turret.attack_parameters then
    flame_turret.attack_parameters.range = 35  -- Reducido de 40 a 35
  end
  log("TDE: Balanced flamethrower turret")
end

-- ===== REMOVE WORM TURRETS FROM NATURAL GENERATION =====
local worm_turrets = {
  "small-worm-turret", "medium-worm-turret", "big-worm-turret", "behemoth-worm-turret"
}

for _, turret_name in pairs(worm_turrets) do
  if data.raw["turret"] and data.raw["turret"][turret_name] then
    if data.raw["turret"][turret_name].autoplace then
      data.raw["turret"][turret_name].autoplace = nil
      log("TDE: Removed autoplace for " .. turret_name)
    end
  end
end

-- ===== BALANCE AMMUNITION - REDUCIR DAÑO INICIAL =====
if data.raw["ammo"] and data.raw["ammo"]["firearm-magazine"] then
  local firearm_mag = data.raw["ammo"]["firearm-magazine"]
  if firearm_mag.ammo_type and firearm_mag.ammo_type.action then
    if type(firearm_mag.ammo_type.action) == "table" then
      for _, action in pairs(firearm_mag.ammo_type.action) do
        if action.action_delivery and action.action_delivery.target_effects then
          for _, effect in pairs(action.action_delivery.target_effects) do
            if effect.type == "damage" and effect.damage and effect.damage.amount then
              effect.damage.amount = effect.damage.amount * 1.1  -- Reducido de 1.3 a 1.1
            end
          end
        end
      end
    end
  end
  log("TDE: Balanced firearm magazine damage")
end

if data.raw["ammo"] and data.raw["ammo"]["piercing-rounds-magazine"] then
  local piercing_mag = data.raw["ammo"]["piercing-rounds-magazine"]
  if piercing_mag.ammo_type and piercing_mag.ammo_type.action then
    if type(piercing_mag.ammo_type.action) == "table" then
      for _, action in pairs(piercing_mag.ammo_type.action) do
        if action.action_delivery and action.action_delivery.target_effects then
          for _, effect in pairs(action.action_delivery.target_effects) do
            if effect.type == "damage" and effect.damage and effect.damage.amount then
              effect.damage.amount = effect.damage.amount * 1.3  -- Mantenido en 1.3 para piercing
            end
          end
        end
      end
    end
  end
  log("TDE: Balanced piercing rounds damage")
end

-- ===== MODIFY SPAWNER BEHAVIOR =====
-- Make spawners always active and more aggressive
if data.raw["unit-spawner"] and data.raw["unit-spawner"]["biter-spawner"] then
  local biter_spawner = data.raw["unit-spawner"]["biter-spawner"]
  biter_spawner.max_health = 500  -- Increased health
  biter_spawner.max_count_of_owned_units = 10  -- More units per spawner
  biter_spawner.max_friends_around_to_spawn = 8  -- Allow spawning with more friends nearby
  
  -- Ensure spawning parameters exist
  if biter_spawner.spawning_cooldown then
    biter_spawner.spawning_cooldown = {180, 120}  -- Faster spawning (3-2 seconds)
  end
  
  log("TDE: Modified biter spawner behavior")
end

if data.raw["unit-spawner"] and data.raw["unit-spawner"]["spitter-spawner"] then
  local spitter_spawner = data.raw["unit-spawner"]["spitter-spawner"]
  spitter_spawner.max_health = 500  -- Increased health
  spitter_spawner.max_count_of_owned_units = 8  -- More units per spawner
  spitter_spawner.max_friends_around_to_spawn = 8  -- Allow spawning with more friends nearby
  
  -- Ensure spawning parameters exist
  if spitter_spawner.spawning_cooldown then
    spitter_spawner.spawning_cooldown = {180, 120}  -- Faster spawning (3-2 seconds)
  end
  
  log("TDE: Modified spitter spawner behavior")
end

-- ===== ENHANCE BITERS FOR TOWER DEFENSE =====
-- Make biters slightly stronger to compensate for buffed turrets
local biter_types = {"small-biter", "medium-biter", "big-biter", "behemoth-biter"}
for _, biter_name in pairs(biter_types) do
  if data.raw["unit"] and data.raw["unit"][biter_name] then
    local biter = data.raw["unit"][biter_name]
    if biter.max_health then
      biter.max_health = math.ceil(biter.max_health * 1.2)  -- 20% more health
    end
    if biter.movement_speed then
      biter.movement_speed = biter.movement_speed * 1.1  -- 10% faster
    end
    log("TDE: Enhanced " .. biter_name)
  end
end

local spitter_types = {"small-spitter", "medium-spitter", "big-spitter", "behemoth-spitter"}
for _, spitter_name in pairs(spitter_types) do
  if data.raw["unit"] and data.raw["unit"][spitter_name] then
    local spitter = data.raw["unit"][spitter_name]
    if spitter.max_health then
      spitter.max_health = math.ceil(spitter.max_health * 1.2)  -- 20% more health
    end
    if spitter.movement_speed then
      spitter.movement_speed = spitter.movement_speed * 1.1  -- 10% faster
    end
    log("TDE: Enhanced " .. spitter_name)
  end
end

-- ===== ENHANCE PLAYER EQUIPMENT =====
-- Make the player stronger for tower defense gameplay
if data.raw["character"] and data.raw["character"]["character"] then
  local character = data.raw["character"]["character"]
  
  -- Increase health
  character.max_health = 300  -- Increased from 100
  
  -- Increase inventory size
  character.inventory_size = 80  -- Increased from 60
  
  -- Increase reach distance
  character.reach_distance = 8  -- Increased from 6
  character.item_pickup_distance = 2  -- Increased pickup range
  character.loot_pickup_distance = 3  -- Increased loot pickup range
  
  log("TDE: Enhanced player character")
end

-- ===== ENHANCE INSERTERS =====
-- Make inserters faster for better factory performance
local inserter_types = {"inserter", "fast-inserter", "long-handed-inserter", "filter-inserter", "stack-inserter", "bulk-inserter"}
for _, inserter_name in pairs(inserter_types) do
  if data.raw["inserter"] and data.raw["inserter"][inserter_name] then
    local inserter = data.raw["inserter"][inserter_name]
    if inserter.rotation_speed then
      inserter.rotation_speed = inserter.rotation_speed * 1.5  -- 50% faster
    end
    if inserter.extension_speed then
      inserter.extension_speed = inserter.extension_speed * 1.5  -- 50% faster
    end
    log("TDE: Enhanced " .. inserter_name .. " speed")
  end
end

-- ===== ENHANCE BELT SPEEDS =====
-- Make belts faster for better throughput
local belt_types = {"transport-belt", "fast-transport-belt", "express-transport-belt", "turbo-transport-belt"}
for _, belt_name in pairs(belt_types) do
  if data.raw["transport-belt"] and data.raw["transport-belt"][belt_name] then
    local belt = data.raw["transport-belt"][belt_name]
    if belt.speed then
      belt.speed = belt.speed * 1.3  -- 30% faster
    end
    log("TDE: Enhanced " .. belt_name .. " speed")
  end
  
  -- Also enhance underground belts
  local underground_name = "underground-" .. belt_name
  if data.raw["underground-belt"] and data.raw["underground-belt"][underground_name] then
    local underground = data.raw["underground-belt"][underground_name]
    if underground.speed then
      underground.speed = underground.speed * 1.3  -- 30% faster
    end
    log("TDE: Enhanced " .. underground_name .. " speed")
  end
  
  -- Also enhance splitters
  local splitter_name = belt_name:gsub("transport%-belt", "splitter")
  if data.raw["splitter"] and data.raw["splitter"][splitter_name] then
    local splitter = data.raw["splitter"][splitter_name]
    if splitter.speed then
      splitter.speed = splitter.speed * 1.3  -- 30% faster
    end
    log("TDE: Enhanced " .. splitter_name .. " speed")
  end
end

-- ===== ENHANCE ASSEMBLING MACHINES =====
-- Make assembling machines faster
local assembler_types = {"assembling-machine-1", "assembling-machine-2", "assembling-machine-3"}
for _, assembler_name in pairs(assembler_types) do
  if data.raw["assembling-machine"] and data.raw["assembling-machine"][assembler_name] then
    local assembler = data.raw["assembling-machine"][assembler_name]
    if assembler.crafting_speed then
      assembler.crafting_speed = assembler.crafting_speed * 1.3  -- 30% faster
    end
    log("TDE: Enhanced " .. assembler_name .. " speed")
  end
end

-- ===== ENHANCE FURNACES =====
local furnace_types = {"stone-furnace", "steel-furnace", "electric-furnace"}
for _, furnace_name in pairs(furnace_types) do
  if data.raw["furnace"] and data.raw["furnace"][furnace_name] then
    local furnace = data.raw["furnace"][furnace_name]
    if furnace.crafting_speed then
      furnace.crafting_speed = furnace.crafting_speed * 1.3  -- 30% faster
    end
    log("TDE: Enhanced " .. furnace_name .. " speed")
  end
end

-- ===== ENHANCE MINING DRILLS =====
local drill_types = {"burner-mining-drill", "electric-mining-drill", "big-mining-drill"}
for _, drill_name in pairs(drill_types) do
  if data.raw["mining-drill"] and data.raw["mining-drill"][drill_name] then
    local drill = data.raw["mining-drill"][drill_name]
    if drill.mining_speed then
      drill.mining_speed = drill.mining_speed * 1.4  -- 40% faster
    end
    log("TDE: Enhanced " .. drill_name .. " speed")
  end
end

-- ===== ENHANCE PUMPJACKS =====
if data.raw["mining-drill"] and data.raw["mining-drill"]["pumpjack"] then
  local pumpjack = data.raw["mining-drill"]["pumpjack"]
  if pumpjack.mining_speed then
    pumpjack.mining_speed = pumpjack.mining_speed * 1.5  -- 50% faster
  end
  log("TDE: Enhanced pumpjack speed")
end

-- ===== ENHANCE LABS =====
if data.raw["lab"] and data.raw["lab"]["lab"] then
  local lab = data.raw["lab"]["lab"]
  if lab.researching_speed then
    lab.researching_speed = lab.researching_speed * 2  -- 100% faster research
  end
  log("TDE: Enhanced lab research speed")
end

-- ===== ENHANCE CHESTS =====
-- Increase chest capacity for better storage
local chest_types = {"wooden-chest", "iron-chest", "steel-chest", "logistic-chest-active-provider", "logistic-chest-passive-provider", "logistic-chest-storage", "logistic-chest-requester", "logistic-chest-buffer"}
for _, chest_name in pairs(chest_types) do
  local chest_type = nil
  if data.raw["container"] and data.raw["container"][chest_name] then
    chest_type = data.raw["container"][chest_name]
  elseif data.raw["logistic-container"] and data.raw["logistic-container"][chest_name] then
    chest_type = data.raw["logistic-container"][chest_name]
  end
  
  if chest_type and chest_type.inventory_size then
    chest_type.inventory_size = math.ceil(chest_type.inventory_size * 1.5)  -- 50% more storage
    log("TDE: Enhanced " .. chest_name .. " capacity")
  end
end

-- ===== ENHANCE POWER GENERATION =====
-- Steam engines
if data.raw["generator"] and data.raw["generator"]["steam-engine"] then
  local steam_engine = data.raw["generator"]["steam-engine"]
  if steam_engine.max_power_output then
    steam_engine.max_power_output = "1200kW"  -- Increased from 900kW
  end
  log("TDE: Enhanced steam engine power")
end

-- Steam turbines
if data.raw["generator"] and data.raw["generator"]["steam-turbine"] then
  local steam_turbine = data.raw["generator"]["steam-turbine"]
  if steam_turbine.max_power_output then
    steam_turbine.max_power_output = "7800kW"  -- Increased from 5800kW
  end
  log("TDE: Enhanced steam turbine power")
end

-- Solar panels
if data.raw["solar-panel"] and data.raw["solar-panel"]["solar-panel"] then
  local solar_panel = data.raw["solar-panel"]["solar-panel"]
  if solar_panel.production then
    solar_panel.production = "90kW"  -- Increased from 60kW
  end
  log("TDE: Enhanced solar panel power")
end

-- Accumulators
if data.raw["accumulator"] and data.raw["accumulator"]["accumulator"] then
  local accumulator = data.raw["accumulator"]["accumulator"]
  if accumulator.energy_source and accumulator.energy_source.buffer_capacity then
    accumulator.energy_source.buffer_capacity = "7.5MJ"  -- Increased from 5MJ
  end
  log("TDE: Enhanced accumulator capacity")
end

-- Add tde-kill-token to all labs' inputs so every tech is researchable
for _, lab in pairs(data.raw["lab"]) do
  if lab.inputs then
    local found = false
    for _, input in ipairs(lab.inputs) do
      if input == "tde-kill-token" then
        found = true
        break
      end
    end
    if not found then
      table.insert(lab.inputs, "tde-kill-token")
    end
  end
end

log("TDE: Completed data-final-fixes modifications v3")