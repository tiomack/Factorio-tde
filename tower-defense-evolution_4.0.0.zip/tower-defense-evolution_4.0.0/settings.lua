-- Runtime settings for Tower Defense Evolution

data:extend({
  {
    type = "int-setting",
    name = "tde-safe-zone-radius",
    setting_type = "runtime-global",
    default_value = 175,
    minimum_value = 100,
    maximum_value = 300,
    order = "a-safe-zone"
  },
  {
    type = "int-setting", 
    name = "tde-wave-interval",
    setting_type = "runtime-global",
    default_value = 10, -- minutes
    minimum_value = 1,
    maximum_value = 30,
    order = "b-wave-interval"
  },
  {
    type = "int-setting",
    name = "tde-nest-spacing",
    setting_type = "runtime-global", 
    default_value = 5,
    minimum_value = 3,
    maximum_value = 15,
    order = "c-nest-spacing"
  },
  {
    type = "double-setting",
    name = "tde-kill-multiplier",
    setting_type = "runtime-global",
    default_value = 1.0,
    minimum_value = 0.5,
    maximum_value = 3.0,
    order = "d-kill-multiplier"
  },
  {
    type = "int-setting",
    name = "tde-resource-amount",
    setting_type = "runtime-global",
    default_value = 2000000,
    minimum_value = 500000,
    maximum_value = 10000000,
    order = "e-resource-amount"
  },
  {
    type = "bool-setting",
    name = "tde-show-kill-messages",
    setting_type = "runtime-global",
    default_value = true,
    order = "f-kill-messages"
  }
})